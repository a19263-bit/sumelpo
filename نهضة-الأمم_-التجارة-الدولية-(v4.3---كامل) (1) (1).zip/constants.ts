
import { CountryState, BudgetAllocation, Policy, Law, TradeResource, Nation, PoliticalParty, GameEvent, NewsItem, PoliticalPartyIdeology, Advisor, TradeUnion, TradeUnionIndustry, TRADE_UNION_INDUSTRY_LABELS_AR } from './types';

export const INITIAL_YEAR = 2024;

export const TRADE_UNIONS_DEFINITIONS: TradeUnion[] = [
  {
    id: 'manu_union_1',
    name: 'Veridian Manufacturing Union',
    nameAr: 'اتحاد عمال صناعات فيريديا',
    industryFocus: TradeUnionIndustry.Manufacturing,
    membershipStrength: 60,
    militancy: 40,
    satisfaction: 55,
  },
  {
    id: 'edu_syndicate_1',
    name: 'National Educators Syndicate',
    nameAr: 'نقابة المعلمين الوطنية',
    industryFocus: TradeUnionIndustry.PublicSector,
    membershipStrength: 75,
    militancy: 30,
    satisfaction: 60,
  },
  {
    id: 'dock_alliance_1',
    name: 'Federal Dockworkers Alliance',
    nameAr: 'تحالف عمال الموانئ الفيدرالي',
    industryFocus: TradeUnionIndustry.Transport,
    membershipStrength: 50,
    militancy: 50,
    satisfaction: 45,
  }
];

export const INITIAL_COUNTRY_STATE: CountryState = {
  year: INITIAL_YEAR,
  currentMonth: 0,
  money: 100000,
  popularLoyalty: 60,
  militaryLoyalty: 60,
  politicalStability: 55,
  techLevel: 1,
  politicalCapital: 50,
  gdp: 50000,
  inflation: 2.5,
  unemployment: 5.0,
  nationalResources: {
    [TradeResource.Oil]: 1000,
    [TradeResource.Minerals]: 800,
    [TradeResource.Food]: 1500,
    [TradeResource.IndustrialGoods]: 500,
    [TradeResource.TechComponents]: 200,
    [TradeResource.LuxuryGoods]: 100,
  },
  debt: 20000,
  oppositionStrength: 20,
  oppositionDiscontent: 15,
  tradeUnions: TRADE_UNIONS_DEFINITIONS.map(tu => ({ ...tu })),
  governmentConfidence: 60, // Initial government confidence
};

export const INITIAL_BUDGET_ALLOCATION: BudgetAllocation = {
  education: 15,
  health: 15,
  defense: 20,
  infrastructure: 15,
  research: 10,
  socialWelfare: 25,
};

export const INITIAL_TAX_RATES = {
  incomeTax: 20,
  corporateTax: 25,
  vatTax: 15,
};

export const POLICIES_DEFINITIONS: Policy[] = [
  {
    id: 'free_media',
    name: 'Freedom of Media',
    nameAr: 'حرية الإعلام',
    description: 'Allows unrestricted operation of media outlets. Increases popular loyalty but may slightly decrease stability if controversial content spreads.',
    descriptionAr: 'يسمح بعمل وسائل الإعلام دون قيود. يزيد الولاء الشعبي ولكنه قد يقلل الاستقرار قليلاً إذا انتشر محتوى مثير للجدل.',
    isActive: false,
    costPoliticalCapitalToggle: 10,
    effects: (state) => ({ popularLoyalty: state.popularLoyalty + (state.popularLoyalty < 95 ? 5 : 0), politicalStability: state.politicalStability - (state.politicalStability > 5 ? 2 : 0) }),
    annualEffects: (state) => ({ popularLoyalty: state.popularLoyalty + (state.popularLoyalty < 98 ? 1 : 0) }),
    opposingIdeologies: ["Conservative", "Nationalist"],
  },
  {
    id: 'internet_censorship',
    name: 'Internet Censorship',
    nameAr: 'الرقابة على الإنترنت',
    description: 'Implements government control over internet content. Decreases popular loyalty but increases political stability.',
    descriptionAr: 'تطبيق الرقابة الحكومية على محتوى الإنترنت. يقلل الولاء الشعبي ولكنه يزيد الاستقرار السياسي.',
    isActive: false,
    costPoliticalCapitalToggle: 15,
    effects: (state) => ({ popularLoyalty: state.popularLoyalty - (state.popularLoyalty > 5 ? 5 : 0), politicalStability: state.politicalStability + (state.politicalStability < 95 ? 5 : 0) }),
    annualEffects: (state) => ({ politicalStability: state.politicalStability + (state.politicalStability < 98 ? 1 : 0) }),
    opposingIdeologies: ["Liberal", "Green"],
  },
  {
    id: 'stimulus_package',
    name: 'Economic Stimulus Package',
    nameAr: 'حزمة تحفيز اقتصادي',
    description: 'Injects government funds into the economy to boost growth. Costs money, slightly increases inflation, reduces unemployment.',
    descriptionAr: 'ضخ أموال حكومية في الاقتصاد لتعزيز النمو. يكلف مالاً، ويزيد التضخم قليلاً، ويقلل البطالة.',
    isActive: false,
    costPoliticalCapitalToggle: 20,
    effects: (state) => ({ money: state.money - 5000, inflation: state.inflation + 0.5, unemployment: state.unemployment - (state.unemployment > 1 ? 0.5 : 0), gdp: state.gdp * 1.01 }),
  }
];

export const LAWS_DEFINITIONS: Law[] = [
  {
    id: 'universal_healthcare',
    name: 'Universal Healthcare Act',
    nameAr: 'قانون الرعاية الصحية الشاملة',
    description: 'Establishes a comprehensive healthcare system for all citizens. Significantly increases health budget needs and popular loyalty.',
    descriptionAr: 'يؤسس نظام رعاية صحية شامل لجميع المواطنين. يزيد بشكل كبير احتياجات ميزانية الصحة والولاء الشعبي.',
    isPassed: false,
    costMoney: 10000,
    costPoliticalCapital: 30,
    techRequirement: 1,
    parliamentarySupportThreshold: 60,
    effects: (state) => ({ popularLoyalty: state.popularLoyalty + (state.popularLoyalty < 90 ? 10 : 0) }),
    annualEffects: (state, budget) => ({ money: state.money - (state.gdp * 0.02) }),
    opposingIdeologies: ["Conservative"], 
  },
  {
    id: 'advanced_research_funding',
    name: 'Advanced Research Funding Bill',
    nameAr: 'مشروع قانون تمويل الأبحاث المتقدمة',
    description: 'Triples government funding for scientific research. Requires high tech level, boosts tech growth significantly.',
    descriptionAr: 'مضاعفة تمويل الحكومة للبحث العلمي ثلاث مرات. يتطلب مستوى تكنولوجيا عالٍ، ويعزز نمو التكنولوجيا بشكل كبير.',
    isPassed: false,
    costMoney: 5000,
    costPoliticalCapital: 25,
    techRequirement: 3,
    parliamentarySupportThreshold: 50,
    effects: (state) => ({ techLevel: state.techLevel + 0.5 }),
    annualEffects: (state, budget) => ({ techLevel: state.techLevel + (budget.research / 20) })
  },
  {
    id: 'anti_corruption_act',
    name: 'Anti-Corruption Act',
    nameAr: 'قانون مكافحة الفساد',
    description: 'Implements strict measures to combat corruption within government and public sector. Increases political stability and popular loyalty over time.',
    descriptionAr: 'يطبق إجراءات صارمة لمكافحة الفساد داخل الحكومة والقطاع العام. يزيد الاستقرار السياسي والولاء الشعبي بمرور الوقت.',
    isPassed: false,
    costMoney: 2000,
    costPoliticalCapital: 35,
    techRequirement: 2,
    parliamentarySupportThreshold: 65,
    effects: (state) => ({ politicalStability: state.politicalStability + 3, popularLoyalty: state.popularLoyalty + 2 }),
    annualEffects: (state) => ({ politicalStability: state.politicalStability + 1, popularLoyalty: state.popularLoyalty + 0.5, politicalCapital: state.politicalCapital + 1}),
    opposingIdeologies: [], 
  }
];

export const NATIONS_DEFINITIONS: Nation[] = [
  {
    id: 'republic_of_veridia',
    name: 'Republic of Veridia',
    nameAr: 'جمهورية فيريديا',
    relation: 65,
    ideology: 'Democratic Capitalism',
    ideologyAr: 'رأسمالية ديمقراطية',
    sells: { [TradeResource.TechComponents]: { price: 140, availability: 120 }, [TradeResource.IndustrialGoods]: {price: 75, availability: 250}},
    buys: { [TradeResource.Oil]: { price: 65, demand: 350 }, [TradeResource.Minerals]: { price: 45, demand: 280 } },
  },
  {
    id: 'solarian_federation',
    name: 'Solarian Federation',
    nameAr: 'الاتحاد السولاري',
    relation: 50,
    ideology: 'Technocratic Neutrality',
    ideologyAr: 'حياد تكنوقراطي',
    sells: { [TradeResource.Food]: { price: 32, availability: 450 }, [TradeResource.LuxuryGoods]: { price: 280, availability: 100 } },
    buys: { [TradeResource.TechComponents]: { price: 150, demand: 70 }, [TradeResource.IndustrialGoods]: { price: 80, demand: 150 } },
  },
  {
    id: 'krypazian_union',
    name: 'Krypazian Union',
    nameAr: 'الاتحاد الكريبازي',
    relation: 35,
    ideology: 'Authoritarian Collectivism',
    ideologyAr: 'جماعية سلطوية',
    sells: { [TradeResource.Minerals]: { price: 30, availability: 700 }, [TradeResource.Oil]: { price: 50, availability: 500 } },
    buys: { [TradeResource.Food]: { price: 40, demand: 450 }, [TradeResource.TechComponents]: { price: 180, demand: 30 } },
  },
  {
    id: 'kingdom_of_eldoria',
    name: 'Kingdom of Eldoria',
    nameAr: 'مملكة إلدوريا',
    relation: 40,
    ideology: 'Constitutional Monarchy',
    ideologyAr: 'ملكية دستورية',
    sells: { [TradeResource.LuxuryGoods]: { price: 220, availability: 150}, [TradeResource.Food]: { price: 38, availability: 300 } },
    buys: { [TradeResource.IndustrialGoods]: { price: 90, demand: 200}, [TradeResource.Oil]: { price: 60, demand: 200 } },
  }
];

export const POLITICAL_PARTIES_DEFINITIONS: PoliticalParty[] = [
  { id: 'liberty_party', name: 'Liberty Party', nameAr: 'حزب الحرية', ideology: 'Liberal', support: 30 },
  { id: 'tradition_party', name: 'Tradition Party', nameAr: 'حزب التقاليد', ideology: 'Conservative', support: 25 },
  { id: 'workers_party', name: 'Workers\' Party', nameAr: 'حزب العمال', ideology: 'Socialist', support: 20 },
  { id: 'patriot_front', name: 'Patriot Front', nameAr: 'الجبهة الوطنية', ideology: 'Nationalist', support: 15 },
  { id: 'earth_first_party', name: 'Earth First Party', nameAr: 'حزب الأرض أولاً', ideology: 'Green', support: 10 },
];

export const ADVISORS_DEFINITIONS: Advisor[] = [
  {
    id: 'econ_advisor_hayes',
    name: 'Dr. Evelyn Hayes', // Was Layla Al-Fahim
    nameAr: 'د. إيفلين هايز',
    role: 'Chief Economic Advisor',
    roleAr: 'كبيرة المستشارين الاقتصاديين',
    loyalty: 75,
    imageUrl: 'https://via.placeholder.com/100/4B5563/FFFFFF?Text=EH',
    getAdvice: (state, budget, policies, laws, parties, unions) => {
      if (state.inflation > 10) return { messageAr: "التضخم الجامح يقوض اقتصادنا! يجب كبح الإنفاق أو رفع الفائدة للسيطرة عليه.", priority: 'high' };
      if (state.unemployment > 10) return { messageAr: "البطالة المرتفعة تهدد السلم الاجتماعي. حان وقت الاستثمار في خلق فرص عمل أو تقديم حزم تحفيزية مدروسة.", priority: 'high' };
      if (state.gdp < INITIAL_COUNTRY_STATE.gdp * 0.95 && state.year > INITIAL_YEAR) return { messageAr: "انكماش الناتج المحلي الإجمالي مقلق. نحتاج إلى سياسات تشجع الاستثمار والإنتاجية.", priority: 'medium' };
      const strikingUnions = unions.filter(u => u.militancy > 70 && u.satisfaction < 30).length;
      if (strikingUnions > 0) return { messageAr: `إضرابات النقابات (${strikingUnions}) تؤثر سلباً على الإنتاج. يجب معالجة مطالبهم أو التفاوض بحزم.`, priority: 'high'};
      return { messageAr: "المؤشرات الاقتصادية مستقرة بشكل عام. لكن اليقظة مطلوبة لمواجهة أي تقلبات قادمة.", priority: 'low' };
    }
  },
  {
    id: 'mil_advisor_thorne',
    name: 'General Marcus Thorne', // Was Omar Sharif
    nameAr: 'الفريق ماركوس ثورن',
    role: 'Chief of Defense Staff',
    roleAr: 'رئيس هيئة الأركان',
    loyalty: 80,
    imageUrl: 'https://via.placeholder.com/100/1E3A8A/FFFFFF?Text=MT',
    getAdvice: (state, budget) => {
      if (state.militaryLoyalty < 40) return { messageAr: "ولاء القوات المسلحة في الحضيض! هذا الوضع خطير للغاية ويتطلب زيادة فورية في ميزانية الدفاع وتحسين أوضاعهم.", priority: 'high' };
      if (budget.defense < 15 && state.techLevel < NATIONS_DEFINITIONS.reduce((avg, n) => avg + (n.relation < 40 ? 3:1) ,0)/NATIONS_DEFINITIONS.length +1) return { messageAr: "ميزانية الدفاع لا تواكب التحديات المحتملة. قد نكون مكشوفين أمام أعدائنا.", priority: 'medium' };
      const hostileNeighbor = NATIONS_DEFINITIONS.find(p => p.relation < 25);
       if (hostileNeighbor) return { messageAr: `العلاقات متوترة للغاية مع ${hostileNeighbor.nameAr}. يجب رفع درجة الاستعداد إلى القصوى.`, priority: 'high'};
      return { messageAr: "قواتنا المسلحة على أهبة الاستعداد. معنوياتهم مرتفعة وقدراتنا الدفاعية موثوقة.", priority: 'low' };
    }
  },
  {
    id: 'pol_advisor_dubois',
    name: 'Ms. Annelise Dubois', // Was Aisha Al-Jamil
    nameAr: 'السيدة أناليس دوبوا',
    role: 'Political Affairs Advisor',
    roleAr: 'مستشارة الشؤون السياسية',
    loyalty: 70,
    imageUrl: 'https://via.placeholder.com/100/374151/FFFFFF?Text=AD',
    getAdvice: (state, budget, policies, laws, parties) => {
      if (state.politicalStability < 35) return { messageAr: "البلاد على شفا الفوضى! الاستقرار السياسي منهار ويجب اتخاذ إجراءات جذرية لاستعادته فورًا.", priority: 'high' };
      if (state.popularLoyalty < 35) return { messageAr: "غضب شعبي عارم! إذا لم نستجب لمطالب الشعب ونحسن ظروفهم، قد نواجه ثورة.", priority: 'high' };
      if (state.oppositionDiscontent > 70 && state.oppositionStrength > 40) return { messageAr: "المعارضة قوية وساخطة للغاية، وقد بدأت في حشد الشارع. الحوار أو القوة، يجب أن نختار بحذر.", priority: 'medium' };
      if(state.governmentConfidence < 40) return { messageAr: "ثقة البرلمان والمؤسسات في الحكومة متدنية. هذا يعرقل قدرتنا على الحكم بفعالية.", priority: 'high'};
      return { messageAr: "الوضع السياسي الداخلي يتطلب حذرًا. هناك بعض التوترات ولكن يمكن السيطرة عليها بالقرارات الصائبة.", priority: 'low' };
    }
  },
  {
    id: 'fin_advisor_li',
    name: 'Mr. Jian Li',
    nameAr: 'السيد جيان لي',
    role: 'Minister of Finance',
    roleAr: 'وزير المالية',
    loyalty: 72,
    imageUrl: 'https://via.placeholder.com/100/047857/FFFFFF?Text=JL',
    getAdvice: (state, budget) => {
      if (state.debt > state.gdp * 1.5) return { messageAr: "الدين القومي وصل إلى مستويات خطيرة تهدد بإفلاس الدولة! يجب تطبيق سياسة تقشف صارمة وزيادة الإيرادات.", priority: 'high' };
      if (state.money < state.gdp * 0.05 && state.debt > state.gdp * 0.5) return { messageAr: "احتياطاتنا المالية منخفضة بشكل مقلق. أي أزمة قد تعصف بنا. يجب ترشيد النفقات وزيادة الإيرادات.", priority: 'medium' };
      const budgetDeficit = Object.values(budget).reduce((sum, val) => sum + val, 0) > 100 && state.money < state.gdp * 0.1;
      if (budgetDeficit) return { messageAr: "الميزانية الحالية تظهر عجزًا كبيرًا. على المدى الطويل، هذا غير مستدام.", priority: 'medium'};
      return { messageAr: "الوضع المالي تحت السيطرة، لكن يجب أن نظل حذرين بشأن الإنفاق والديون.", priority: 'low' };
    }
  },
  {
    id: 'for_advisor_petrova',
    name: 'Ambassador Sofia Petrova',
    nameAr: 'السفيرة صوفيا بيتروفا',
    role: 'Minister of Foreign Affairs',
    roleAr: 'وزيرة الخارجية',
    loyalty: 68,
    imageUrl: 'https://via.placeholder.com/100/7C3AED/FFFFFF?Text=SP',
    getAdvice: (state, budget, policies, laws, parties, unions) => { // Added unions to params
      const hostileNations = NATIONS_DEFINITIONS.filter(n => n.relation < 30).length;
      if (hostileNations > 1) return { messageAr: `لدينا عدة دول معادية (${hostileNations}). هذا يضعف موقفنا الدولي ويجب العمل على تحسين العلاقات مع البعض على الأقل.`, priority: 'high' };
      const avgRelation = NATIONS_DEFINITIONS.reduce((sum, n) => sum + n.relation, 0) / NATIONS_DEFINITIONS.length;
      if (avgRelation < 45) return { messageAr: "علاقاتنا الدولية بشكل عام ليست جيدة. نحتاج إلى دبلوماسية أكثر نشاطًا وفعالية.", priority: 'medium' };
      return { messageAr: "موقفنا الدولي جيد. استمرار الدبلوماسية الحكيمة سيعزز مكانتنا في العالم.", priority: 'low' };
    }
  },
  {
    id: 'sec_advisor_finch',
    name: 'Director Alistair Finch',
    nameAr: 'المدير أليستر فينش',
    role: 'Director of National Security',
    roleAr: 'مدير الأمن الوطني',
    loyalty: 85,
    imageUrl: 'https://via.placeholder.com/100/64748B/FFFFFF?Text=AF',
    getAdvice: (state, budget, policies, laws, parties, unions) => { // Added unions to params
      if (state.politicalStability < 40 && state.oppositionDiscontent > 60) return { messageAr: "الجبهة الداخلية مهددة بالانهيار. هناك معلومات عن مخططات لزعزعة الأمن. يجب رفع درجة التأهب الأمني.", priority: 'high' };
      const activeStrikes = unions.filter(u => u.militancy > 60 && u.satisfaction < 35).length > 0;
      if(activeStrikes && state.popularLoyalty < 50) return { messageAr: "الإضرابات المتزامنة مع انخفاض الولاء الشعبي تشكل تهديدًا أمنيًا. يجب التعامل مع الموقف بحزم وحكمة.", priority: 'medium'};
      // Future: check for espionage or terrorism risk based on relations and tech
      return { messageAr: "الوضع الأمني مستقر. قواتنا الأمنية تقوم بواجبها على أكمل وجه.", priority: 'low' };
    }
  }
];


export const GAME_EVENTS_DEFINITIONS: GameEvent[] = [
  {
    id: 'economic_boom',
    title: 'Global Economic Boom!',
    titleAr: 'ازدهار اقتصادي عالمي!',
    description: 'Favorable international conditions have led to a surge in global trade and investment. Your nation stands to benefit!',
    descriptionAr: 'أدت الظروف الدولية المواتية إلى طفرة في التجارة والاستثمار العالميين. أمتك على وشك الاستفادة!',
    imageUrl: 'https://picsum.photos/400/200?random=1',
    options: [
      { text: 'Capitalize on it!', textAr: 'استغل الفرصة!', effects: (state) => ({ gdp: state.gdp * 1.1, money: state.money + 10000, popularLoyalty: state.popularLoyalty + 5 }) },
      { text: 'Save for a rainy day.', textAr: 'ادخر لوقت الحاجة.', effects: (state) => ({ money: state.money + 15000 }) },
    ],
    triggerCondition: (state) => Math.random() < 0.05,
  },
  {
    id: 'natural_disaster',
    title: 'Natural Disaster Strikes!',
    titleAr: 'كارثة طبيعية تضرب البلاد!',
    description: 'A major earthquake has devastated a key industrial region. Immediate action is required.',
    descriptionAr: 'زلزال كبير يدمر منطقة صناعية رئيسية. التدخل الفوري مطلوب.',
    imageUrl: 'https://picsum.photos/400/200?random=2',
    options: [
      { text: 'Provide Full Aid (Costly)', textAr: 'تقديم مساعدات كاملة (مكلف)', effects: (state) => ({ money: state.money - 20000, popularLoyalty: state.popularLoyalty + 10, politicalStability: state.politicalStability - 5, gdp: state.gdp * 0.98 }) },
      { text: 'Limited Assistance', textAr: 'مساعدة محدودة', effects: (state) => ({ money: state.money - 5000, popularLoyalty: state.popularLoyalty - 10, politicalStability: state.politicalStability - 10, gdp: state.gdp * 0.95 }) },
    ],
    triggerCondition: (state) => Math.random() < 0.03 && state.money > 25000,
  },
  {
    id: 'tech_breakthrough',
    title: 'Technological Breakthrough!',
    titleAr: 'اختراق تكنولوجي!',
    description: 'Your scientists have made a groundbreaking discovery! This could revolutionize an industry.',
    descriptionAr: 'حقق علماؤك اكتشافًا ثوريًا! هذا يمكن أن يحدث ثورة في صناعة ما.',
    imageUrl: 'https://picsum.photos/400/200?random=3',
    options: [
      { text: 'Invest heavily in development', textAr: 'استثمر بكثافة في التطوير', effects: (state) => ({ techLevel: state.techLevel + 1, money: state.money - 5000, politicalCapital: state.politicalCapital + 10 }) },
      { text: 'Sell the patent internationally', textAr: 'بيع براءة الاختراع دوليًا', effects: (state) => ({ money: state.money + 10000, politicalCapital: state.politicalCapital + 5 }) },
    ],
    triggerCondition: (state, budget) => state.techLevel > 2 && Math.random() < 0.08 && (budget.research || INITIAL_BUDGET_ALLOCATION.research) > 10,
  },
  {
    id: 'opposition_protests',
    title: 'Opposition Organizes Mass Protests',
    titleAr: 'المعارضة تنظم احتجاجات واسعة',
    description: 'Citing unpopular government policies, opposition parties have called for mass street protests. This is challenging your authority.',
    descriptionAr: 'مستشهدة بسياسات حكومية لا تحظى بشعبية، دعت أحزاب المعارضة إلى احتجاجات شعبية واسعة. هذا يتحدى سلطتكم.',
    imageUrl: 'https://picsum.photos/400/200?random=4',
    options: [
        { text: 'Negotiate with Protest Leaders', textAr: 'تفاوض مع قادة الاحتجاج', effects: (state) => ({ politicalCapital: state.politicalCapital - 15, politicalStability: state.politicalStability + 5, oppositionDiscontent: Math.max(0, state.oppositionDiscontent - 20) }) },
        { text: 'Deploy Security Forces (Crackdown)', textAr: 'نشر قوات الأمن (قمع)', effects: (state) => ({ militaryLoyalty: state.militaryLoyalty - 10, popularLoyalty: state.popularLoyalty - 15, politicalStability: state.politicalStability + 10, oppositionDiscontent: state.oppositionDiscontent + 15, governmentConfidence: state.governmentConfidence - 5 }) },
        { text: 'Ignore the Protests', textAr: 'تجاهل الاحتجاجات', effects: (state) => ({ politicalStability: state.politicalStability - 10, popularLoyalty: state.popularLoyalty - 5, oppositionDiscontent: state.oppositionDiscontent + 5, governmentConfidence: state.governmentConfidence - 3 }) },
    ],
    triggerCondition: (state) => state.oppositionDiscontent > 65 && state.oppositionStrength > 30 && Math.random() < 0.2,
  },
  {
    id: 'political_scandal',
    title: 'Political Scandal Erupts!',
    titleAr: 'فضيحة سياسية تندلع!',
    description: 'Allegations of corruption involving a high-ranking official have surfaced, fueled by opposition media. Public trust is shaken.',
    descriptionAr: 'ظهرت مزاعم فساد تطال مسؤولاً رفيع المستوى، تغذيها وسائل إعلام معارضة. ثقة الجمهور اهتزت.',
    imageUrl: 'https://picsum.photos/400/200?random=5',
    options: [
        { text: 'Launch Full Investigation (Costly PC)', textAr: 'فتح تحقيق كامل (يكلف رأس مال سياسي)', effects: (state) => ({ politicalCapital: state.politicalCapital - 25, politicalStability: state.politicalStability + 5, popularLoyalty: state.popularLoyalty + 5, governmentConfidence: state.governmentConfidence - 2 }) },
        { text: 'Deny Allegations, Blame Opposition', textAr: 'إنكار المزاعم وإلقاء اللوم على المعارضة', effects: (state) => ({ politicalStability: state.politicalStability - 5, popularLoyalty: state.popularLoyalty - 10, oppositionDiscontent: state.oppositionDiscontent + 10, governmentConfidence: state.governmentConfidence - 8 }) },
    ],
    triggerCondition: (state) => state.politicalStability < 50 && state.oppositionStrength > 25 && Math.random() < 0.1,
  },
  {
    id: 'union_demands_wage_increase',
    title: 'Trade Union Demands Wage Increase',
    titleAr: 'نقابة عمالية تطالب بزيادة الأجور',
    description: (state: CountryState) => {
      const demandingUnion = state.tradeUnions.find(u => u.satisfaction < 40 && u.militancy > 50 && u.membershipStrength > 40);
      return `The ${demandingUnion?.name || 'major trade union'} is demanding an immediate 10% wage increase and improved working conditions, threatening a strike.`;
    },
    descriptionAr: (state: CountryState) => {
      const demandingUnion = state.tradeUnions.find(u => u.satisfaction < 40 && u.militancy > 50 && u.membershipStrength > 40);
      return `نقابة ${demandingUnion?.nameAr || 'عمالية كبرى'} تطالب بزيادة فورية في الأجور بنسبة 10% وتحسين ظروف العمل، مهددة بالإضراب الشامل إذا لم تتم الاستجابة لمطالبها.`;
    },
    imageUrl: 'https://picsum.photos/400/200?random=6',
    options: [
      { text: 'Meet Demands (Costly)', textAr: 'الاستجابة للمطالب (مكلف)', effects: (state) => {
        const union = state.tradeUnions.find(u => u.satisfaction < 40 && u.militancy > 50 && u.membershipStrength > 40);
        return { 
          money: state.money - (state.gdp * 0.01), // Costly wage increase
          tradeUnions: state.tradeUnions.map(u => u.id === union?.id ? {...u, satisfaction: u.satisfaction + 30, militancy: u.militancy - 15} : u),
          popularLoyalty: state.popularLoyalty + 3,
        };
      }},
      { text: 'Negotiate for a Lesser Deal', textAr: 'التفاوض على صفقة أقل', effects: (state) => {
        const union = state.tradeUnions.find(u => u.satisfaction < 40 && u.militancy > 50 && u.membershipStrength > 40);
        return {
          politicalCapital: state.politicalCapital - 10,
          money: state.money - (state.gdp * 0.005),
          tradeUnions: state.tradeUnions.map(u => u.id === union?.id ? {...u, satisfaction: u.satisfaction + 15, militancy: u.militancy - 5} : u),
          popularLoyalty: state.popularLoyalty + 1,
        };
      }},
      { text: 'Reject Demands (Risk Strike)', textAr: 'رفض المطالب (مخاطرة بالإضراب)', effects: (state) => {
        const union = state.tradeUnions.find(u => u.satisfaction < 40 && u.militancy > 50 && u.membershipStrength > 40);
        return {
          tradeUnions: state.tradeUnions.map(u => u.id === union?.id ? {...u, satisfaction: u.satisfaction - 10, militancy: Math.min(100, u.militancy + 20)} : u),
          politicalStability: state.politicalStability - 5,
        };
      }},
    ],
    triggerCondition: (state, budget, parties, unions) => unions !== undefined && unions.some(u => u.satisfaction < 40 && u.militancy > 50 && u.membershipStrength > 40 && Math.random() < 0.25),
  },
  {
    id: 'major_strike_action',
    title: 'Major Strike Action Paralyzes Industry',
    titleAr: 'إضراب كبير يشل قطاعًا صناعيًا',
    description: (state: CountryState) => {
      const strikingUnion = state.tradeUnions.find(u => u.militancy > 70 && u.satisfaction < 20);
      return `The government's refusal to meet the demands of the ${strikingUnion?.name || 'workers\''} union has led to a full-blown strike in the ${strikingUnion ? strikingUnion.industryFocus : 'vital'} sector. Production is halted, and losses are mounting.`;
    },
    descriptionAr: (state: CountryState) => {
       const strikingUnion = state.tradeUnions.find(u => u.militancy > 70 && u.satisfaction < 20);
      return `أدى رفض الحكومة لمطالب نقابة ${strikingUnion?.nameAr || 'عمالية'} إلى إضراب شامل في قطاع ${strikingUnion ? TRADE_UNION_INDUSTRY_LABELS_AR[strikingUnion.industryFocus] : 'حيوي'}. الإنتاج متوقف والخسائر تتزايد بسرعة.`;
    },
    imageUrl: 'https://picsum.photos/400/200?random=7',
    options: [
      { text: 'Force Workers Back (Authoritarian)', textAr: 'إجبار العمال على العودة (سلطوي)', effects: (state) => {
        const union = state.tradeUnions.find(u => u.militancy > 70 && u.satisfaction < 20);
        return { 
          militaryLoyalty: state.militaryLoyalty + 5, // Shows strength
          popularLoyalty: state.popularLoyalty - 20,
          politicalStability: state.politicalStability - 10,
          tradeUnions: state.tradeUnions.map(u => u.id === union?.id ? {...u, satisfaction: Math.max(0, u.satisfaction - 15), militancy: Math.max(10, u.militancy - 30)} : u), // Strike broken, but resentment
          gdp: state.gdp * 0.98, // Short term hit, then recovery
          governmentConfidence: state.governmentConfidence - 10,
        };
      }},
      { text: 'Offer Concessions to End Strike', textAr: 'تقديم تنازلات لإنهاء الإضراب', effects: (state) => {
         const union = state.tradeUnions.find(u => u.militancy > 70 && u.satisfaction < 20);
        return {
          money: state.money - (state.gdp * 0.015),
          politicalCapital: state.politicalCapital - 15,
          tradeUnions: state.tradeUnions.map(u => u.id === union?.id ? {...u, satisfaction: u.satisfaction + 40, militancy: u.militancy - 20} : u),
          popularLoyalty: state.popularLoyalty + 5,
          gdp: state.gdp * 0.97, // Hit during strike
        };
      }},
    ],
    triggerCondition: (state, budget, parties, unions) => unions !== undefined && unions.some(u => u.militancy > 70 && u.satisfaction < 20 && Math.random() < 0.4),
  }
];

export const NEWS_ITEMS_BASE: NewsItem[] = [
  { id: 'n1', content: "Stock market shows steady growth this quarter.", contentAr: "سوق الأسهم يظهر نموًا ثابتًا هذا الربع.", type: 'info' },
  { id: 'n2', content: "Neighboring countries report increased border tensions.", contentAr: "الدول المجاورة تبلغ عن زيادة التوترات الحدودية.", type: 'warning' },
  { id: 'n3', content: "Analysts predict a rise in global oil prices.", contentAr: "المحللون يتوقعون ارتفاع أسعار النفط العالمية.", type: 'neutral' },
  { id: 'n4', content: "New survey shows public satisfaction with public transport.", contentAr: "مسح جديد يظهر رضا الجمهور عن وسائل النقل العام.", type: 'success' },
  { id: 'n5', content: "Debate rages over proposed education reforms.", contentAr: "جدل محتدم حول إصلاحات التعليم المقترحة.", type: 'neutral' },
  { id: 'n6', content: "Opposition parties criticize government's economic policies.", contentAr: "أحزاب المعارضة تنتقد سياسات الحكومة الاقتصادية.", type: 'warning' },
];

export const MAX_TECH_LEVEL = 10;
export const TECH_POINTS_PER_LEVEL = 100;
export const INTEREST_RATE_ON_DEBT = 0.05;

export const MONTH_NAMES_AR = [
  "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
  "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
];
