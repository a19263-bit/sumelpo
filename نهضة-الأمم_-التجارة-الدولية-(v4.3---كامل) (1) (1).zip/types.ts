
export enum GameTab {
  Dashboard = "Dashboard",
  Economy = "Economy",
  Budget = "Budget",
  Policies = "Policies",
  Laws = "Laws",
  Trade = "Trade",
  InternalAffairs = "Internal Affairs",
  ExternalAffairs = "External Affairs",
  Cabinet = "Cabinet", 
}

export const GAME_TAB_LABELS: Record<GameTab, string> = {
  [GameTab.Dashboard]: "لوحة التحكم",
  [GameTab.Economy]: "الاقتصاد",
  [GameTab.Budget]: "الميزانية",
  [GameTab.Policies]: "السياسات",
  [GameTab.Laws]: "القوانين",
  [GameTab.Trade]: "التجارة الدولية",
  [GameTab.InternalAffairs]: "الشؤون الداخلية",
  [GameTab.ExternalAffairs]: "الشؤون الخارجية",
  [GameTab.Cabinet]: "الديوان الرئاسي",
};

export interface CountryState {
  year: number;
  currentMonth: number;
  money: number;
  popularLoyalty: number;
  militaryLoyalty: number;
  politicalStability: number;
  techLevel: number;
  politicalCapital: number;
  gdp: number;
  inflation: number;
  unemployment: number;
  nationalResources: Record<TradeResource, number>;
  debt: number;
  oppositionStrength: number; 
  oppositionDiscontent: number; 
  tradeUnions: TradeUnion[];
  governmentConfidence: number; // 0-100: How much confidence parliament/system has in the current government
}

export interface BudgetAllocation {
  education: number;
  health: number;
  defense: number;
  infrastructure: number;
  research: number;
  socialWelfare: number;
}

export interface Policy {
  id: string;
  name: string;
  nameAr: string; 
  description: string;
  descriptionAr: string; 
  isActive: boolean;
  costPoliticalCapitalToggle: number;
  effects: (state: CountryState) => Partial<CountryState>; 
  annualEffects?: (state: CountryState, budget: BudgetAllocation) => Partial<CountryState>;
  opposingIdeologies?: PoliticalPartyIdeology[];
}

export interface Law {
  id: string;
  name: string;
  nameAr: string; 
  description: string;
  descriptionAr: string; 
  isPassed: boolean;
  costMoney: number;
  costPoliticalCapital: number;
  techRequirement: number; 
  parliamentarySupportThreshold: number; 
  effects: (state: CountryState) => Partial<CountryState>; 
  annualEffects?: (state: CountryState, budget: BudgetAllocation) => Partial<CountryState>;
  opposingIdeologies?: PoliticalPartyIdeology[];
}

export enum TradeResource {
  Oil = "Oil",
  Minerals = "Minerals",
  Food = "Food",
  IndustrialGoods = "Industrial Goods",
  TechComponents = "Tech Components",
  LuxuryGoods = "Luxury Goods",
}

export const TRADE_RESOURCE_LABELS_AR: Record<TradeResource, string> = {
  [TradeResource.Oil]: "النفط",
  [TradeResource.Minerals]: "المعادن",
  [TradeResource.Food]: "الغذاء",
  [TradeResource.IndustrialGoods]: "السلع الصناعية",
  [TradeResource.TechComponents]: "المكونات التقنية",
  [TradeResource.LuxuryGoods]: "السلع الفاخرة",
};

export interface Nation {
  id: string;
  name: string; // Non-Arabic name
  nameAr: string; 
  relation: number; 
  sells: Partial<Record<TradeResource, { price: number; availability: number }>>;
  buys: Partial<Record<TradeResource, { price: number; demand: number }>>;
  ideology?: string; 
  ideologyAr?: string; 
}

export type PoliticalPartyIdeology = "Liberal" | "Conservative" | "Socialist" | "Nationalist" | "Green" | "Populist";
export const POLITICAL_PARTY_IDEOLOGY_LABELS_AR: Record<PoliticalPartyIdeology, string> = {
  "Liberal": "ليبرالي",
  "Conservative": "محافظ",
  "Socialist": "اشتراكي",
  "Nationalist": "قومي",
  "Green": "بيئي",
  "Populist": "شعوبي",
};

export interface PoliticalParty {
  id: string;
  name: string;
  nameAr: string; 
  ideology: PoliticalPartyIdeology;
  support: number; 
}

export interface Advisor {
  id: string;
  name: string; // Non-Arabic name
  nameAr: string; // Arabic name for UI display if needed, or can be same as roleAr
  role: string;   // Non-Arabic role
  roleAr: string; // Arabic role for UI display
  loyalty: number; 
  imageUrl?: string; 
  getAdvice: (
    state: CountryState, 
    budget: BudgetAllocation, 
    policies: Policy[], 
    laws: Law[],
    parties: PoliticalParty[],
    unions: TradeUnion[]
  ) => { messageAr: string; priority: 'high' | 'medium' | 'low' };
}

export enum TradeUnionIndustry {
  Manufacturing = "Manufacturing",
  PublicSector = "Public Sector",
  Mining = "Mining",
  Transport = "Transport",
  Agriculture = "Agriculture",
  General = "General",
}

export const TRADE_UNION_INDUSTRY_LABELS_AR: Record<TradeUnionIndustry, string> = {
  [TradeUnionIndustry.Manufacturing]: "الصناعات التحويلية",
  [TradeUnionIndustry.PublicSector]: "القطاع العام",
  [TradeUnionIndustry.Mining]: "التعدين",
  [TradeUnionIndustry.Transport]: "النقل والمواصلات",
  [TradeUnionIndustry.Agriculture]: "الزراعة",
  [TradeUnionIndustry.General]: "اتحاد عام",
};

export interface TradeUnion {
  id: string;
  name: string; // Non-Arabic name
  nameAr: string;
  industryFocus: TradeUnionIndustry;
  membershipStrength: number; // 0-100, percentage of workforce in that sector or overall influence
  militancy: number; // 0-100, willingness to strike or protest
  satisfaction: number; // 0-100, how happy they are with current conditions
}

export interface GameEvent {
  id: string;
  title: string;
  titleAr: string; 
  description: string | ((state: CountryState) => string);
  descriptionAr: string | ((state: CountryState) => string); 
  imageUrl?: string;
  options: {
    text: string;
    textAr: string; 
    effects: (state: CountryState) => Partial<CountryState>;
  }[];
  triggerCondition?: (state: CountryState, budget: BudgetAllocation, parties?: PoliticalParty[], unions?: TradeUnion[]) => boolean; 
}

export type NewsItemType = "info" | "warning" | "success" | "neutral" | "advisor";
export const NEWS_ITEM_TYPE_LABELS_AR: Record<NewsItemType, string> = {
  "info": "معلومات",
  "warning": "تحذير",
  "success": "نجاح",
  "neutral": "محايد",
  "advisor": "نصيحة ديوان",
};

export interface NewsItem {
  id: string;
  content: string;
  contentAr: string; 
  type: NewsItemType;
}
