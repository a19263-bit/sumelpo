
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { GameTab, CountryState, BudgetAllocation, Policy, Law, Nation, PoliticalParty, GameEvent, NewsItem, TradeResource, GAME_TAB_LABELS, TRADE_RESOURCE_LABELS_AR, Advisor, TradeUnion } from './types';
import { INITIAL_COUNTRY_STATE, INITIAL_BUDGET_ALLOCATION, INITIAL_TAX_RATES, POLICIES_DEFINITIONS, LAWS_DEFINITIONS, NATIONS_DEFINITIONS, POLITICAL_PARTIES_DEFINITIONS, GAME_EVENTS_DEFINITIONS, NEWS_ITEMS_BASE, TECH_POINTS_PER_LEVEL, MAX_TECH_LEVEL, INTEREST_RATE_ON_DEBT, INITIAL_YEAR, ADVISORS_DEFINITIONS, TRADE_UNIONS_DEFINITIONS } from './constants';
import TopBar from './components/TopBar';
import SideBar from './components/SideBar';
import EconomyTab from './components/tabs/EconomyTab';
import BudgetTab from './components/tabs/BudgetTab';
import PoliciesTab from './components/tabs/PoliciesTab';
import LawsTab from './components/tabs/LawsTab';
import TradeTab from './components/tabs/TradeTab';
import InternalAffairsTab from './components/tabs/InternalAffairsTab';
import ExternalAffairsTab from './components/tabs/ExternalAffairsTab';
import DashboardTab from './components/tabs/DashboardTab';
import CabinetTab from './components/tabs/CabinetTab'; 
import EventModal from './components/EventModal';
import GameOverScreen from './components/GameOverScreen';
import NewsTicker from './components/NewsTicker';

const MONTH_DURATION_MS = 5000; 

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<GameTab>(GameTab.Dashboard);
  const [countryState, setCountryState] = useState<CountryState>(INITIAL_COUNTRY_STATE);
  const [budget, setBudget] = useState<BudgetAllocation>(INITIAL_BUDGET_ALLOCATION);
  const [taxRates, setTaxRates] = useState(INITIAL_TAX_RATES);
  const [policies, setPolicies] = useState<Policy[]>(() => POLICIES_DEFINITIONS.map(p => ({ ...p })));
  const [laws, setLaws] = useState<Law[]>(() => LAWS_DEFINITIONS.map(l => ({ ...l })));
  const [tradePartners, setTradePartners] = useState<Nation[]>(() => NATIONS_DEFINITIONS.map(n => ({...n})));
  const [politicalParties, setPoliticalParties] = useState<PoliticalParty[]>(() => POLITICAL_PARTIES_DEFINITIONS.map(p => ({ ...p })));
  const [advisors, setAdvisors] = useState<Advisor[]>(() => ADVISORS_DEFINITIONS.map(a => ({ ...a })));
  const [tradeUnions, setTradeUnions] = useState<TradeUnion[]>(() => TRADE_UNIONS_DEFINITIONS.map(tu => ({ ...tu })));
  const [currentEvent, setCurrentEvent] = useState<GameEvent | null>(null);
  const [gameOverMessage, setGameOverMessage] = useState<string | null>(null);
  const [newsFeed, setNewsFeed] = useState<NewsItem[]>(() => NEWS_ITEMS_BASE.slice(0, 5).map(n => ({...n, id: Math.random().toString() })));
  const [currentTechProgress, setCurrentTechProgress] = useState(0);
  const [isGamePaused, setIsGamePaused] = useState(false);

  const gameTickIntervalRef = useRef<number | null>(null);
  const lastProcessedYearRef = useRef<number>(INITIAL_COUNTRY_STATE.year -1);


  const calculateTechLevel = (currentPoints: number, currentLevel: number): { level: number, progress: number} => {
    let level = currentLevel;
    let points = currentPoints;
    let requiredForNext = TECH_POINTS_PER_LEVEL * level;
    if (level >= MAX_TECH_LEVEL) return {level: MAX_TECH_LEVEL, progress: 0};
    while (points >= requiredForNext && level < MAX_TECH_LEVEL) {
      points -= requiredForNext;
      level++;
      if (level < MAX_TECH_LEVEL) {
        requiredForNext = TECH_POINTS_PER_LEVEL * level;
      } else {
        points = 0; 
      }
    }
    return { level, progress: points };
  };

  const processYearEndLogic = useCallback(() => {
    setCountryState(prevState => {
      let newState: CountryState = { ...prevState };
      
      const totalTaxRate = (taxRates.incomeTax + taxRates.corporateTax + taxRates.vatTax) / 3 / 100;
      const taxRevenue = newState.gdp * totalTaxRate * (0.8 + newState.politicalStability / 500);
      newState.money += taxRevenue;

      const totalBudgetPercentage = Object.values(budget).reduce((sum, val) => sum + val, 0);
      const totalSpending = newState.gdp * (Math.min(totalBudgetPercentage, 100) / 100) * 0.5; 
      newState.money -= totalSpending;
      
      if (newState.debt > 0) {
        const interest = newState.debt * INTEREST_RATE_ON_DEBT;
        newState.money -= interest;
        // newState.debt += interest; // Debt interest accumulation moved to after money check
      }
      
      if (newState.money < 0) {
        newState.debt += Math.abs(newState.money);
        newState.money = 0;
      }
      if (prevState.debt > 0) { // Apply interest after potentially increasing debt from deficit
         newState.debt += prevState.debt * INTEREST_RATE_ON_DEBT;
      }


      policies.filter(p => p.isActive && p.annualEffects).forEach(p => {
        const effects = p.annualEffects!(newState, budget);
        newState = { ...newState, ...effects };
      });
      laws.filter(l => l.isPassed && l.annualEffects).forEach(l => {
        const effects = l.annualEffects!(newState, budget);
        newState = { ...newState, ...effects };
      });
      
      newState.popularLoyalty += (budget.health + budget.education + budget.socialWelfare) / 15 - (taxRates.incomeTax + taxRates.vatTax) / 20 - newState.unemployment / 5;
      newState.militaryLoyalty += budget.defense / 10 - 2;
      newState.popularLoyalty = Math.max(0, Math.min(100, newState.popularLoyalty));
      newState.militaryLoyalty = Math.max(0, Math.min(100, newState.militaryLoyalty));
      
      const techInvestmentEffect = budget.research / 5;
      const newTechPoints = currentTechProgress + techInvestmentEffect + (laws.find(l => l.isPassed && l.id === 'advanced_research_funding') ? 10 : 0);
      const {level: updatedTechLevel, progress: updatedTechProgress} = calculateTechLevel(newTechPoints, newState.techLevel);
      newState.techLevel = updatedTechLevel;
      setCurrentTechProgress(updatedTechProgress);

      let gdpGrowthFactor = (budget.infrastructure / 200) + (newState.techLevel / 150) + (newState.politicalStability / 2000) - 0.015;
      gdpGrowthFactor += policies.filter(p => p.isActive && p.id === 'stimulus_package').length * 0.01;
      
      // Impact of strikes on GDP
      const strikingUnionFactor = newState.tradeUnions.reduce((factor, tu) => {
        if (tu.militancy > 70 && tu.satisfaction < 30) { // If union is striking
          return factor + (tu.membershipStrength / 100) * 0.05; // Each striking union can reduce GDP growth potential
        }
        return factor;
      }, 0);
      gdpGrowthFactor -= strikingUnionFactor;

      newState.gdp *= (1 + gdpGrowthFactor);
      
      newState.inflation += (totalSpending / (prevState.gdp === 0 ? 1: prevState.gdp)) * 5 - (gdpGrowthFactor * 10) - (newState.politicalStability / 1000) ;
      newState.inflation = Math.max(0.1, Math.min(20, newState.inflation));

      newState.unemployment -= gdpGrowthFactor * 50 - (newState.inflation / 10);
      if (strikingUnionFactor > 0) newState.unemployment += strikingUnionFactor * 10; // Strikes increase unemployment
      newState.unemployment = Math.max(1, Math.min(25, newState.unemployment));
      
      newState.politicalCapital += Math.floor(newState.politicalStability / 20) - 1;
      newState.politicalCapital = Math.max(0, Math.min(200, newState.politicalCapital));

      // Opposition calculations
      let newOppositionStrength = 0;
      let newOppositionDiscontent = 0;
      
      politicalParties.forEach(party => {
          let isOpposed = false;
          if (party.ideology === "Populist" && newState.popularLoyalty < 50) isOpposed = true;
          if (laws.some(law => law.isPassed && law.opposingIdeologies?.includes(party.ideology))) isOpposed = true;
          if (policies.some(policy => policy.isActive && policy.opposingIdeologies?.includes(party.ideology))) isOpposed = true;
          // Parties with ideologies opposite to government confidence might also be opposed
          if (newState.governmentConfidence < 40 && (party.ideology === "Nationalist" || party.ideology === "Populist")) isOpposed = true;


          if (isOpposed) {
            newOppositionStrength += party.support / 2;
            newOppositionDiscontent += party.support / 3;
          }
      });
      if (newState.popularLoyalty < 45) newOppositionDiscontent += 10;
      if (newState.politicalStability < 45) newOppositionDiscontent += 10;
      if (taxRates.incomeTax > 35 || taxRates.vatTax > 20) newOppositionDiscontent += 5;

      newState.oppositionStrength = Math.max(0, Math.min(100, (newState.oppositionStrength * 0.5) + (newOppositionStrength * 0.5) )); 
      newState.oppositionDiscontent = Math.max(0, Math.min(100, (newState.oppositionDiscontent * 0.5) + (newOppositionDiscontent * 0.5) ));

      // Trade Union Updates
      newState.tradeUnions = newState.tradeUnions.map(tu => {
        let satisfactionChange = 0;
        if (newState.unemployment > 8) satisfactionChange -= 5; else satisfactionChange += 2;
        if (newState.inflation > 7) satisfactionChange -= 5; else satisfactionChange += 1;
        if (policies.some(p => p.isActive && (p.id === 'stimulus_package' || p.id === 'social_welfare_expansion'))) satisfactionChange += 3; // Example policy effects
        if (laws.some(l => l.isPassed && l.id ==='universal_healthcare')) satisfactionChange +=4;

        let newSatisfaction = Math.max(0, Math.min(100, tu.satisfaction + satisfactionChange));
        
        let militancyChange = 0;
        if (newSatisfaction < 30) militancyChange += 10;
        else if (newSatisfaction < 50) militancyChange += 5;
        else militancyChange -= 5;
        if (newState.oppositionDiscontent > 60) militancyChange += 5; // General unrest fuels militancy

        let newMilitancy = Math.max(0, Math.min(100, tu.militancy + militancyChange));
        
        // If a strike was ongoing and not resolved by an event, it might reduce militancy slightly from exhaustion, but satisfaction remains low.
        if (tu.militancy > 70 && tu.satisfaction < 30 && !currentEvent) { // Check if strike might have "ended" without resolution
            newMilitancy = Math.max(10, newMilitancy - 10); // Fatigue sets in
        }


        return { ...tu, satisfaction: newSatisfaction, militancy: newMilitancy };
      });
      // Effects of union satisfaction on broader state
      const avgUnionSatisfaction = newState.tradeUnions.reduce((sum, tu) => sum + tu.satisfaction, 0) / (newState.tradeUnions.length || 1);
      newState.popularLoyalty += (avgUnionSatisfaction - 50) / 10; // Satisfied unions boost loyalty
      newState.politicalStability += (avgUnionSatisfaction - 50) / 15;


      // Political Stability influenced by many factors including opposition
      let stabilityBase = (newState.popularLoyalty + newState.militaryLoyalty) / 2.2;
      stabilityBase += policies.filter(p=>p.isActive && p.id === 'internet_censorship').length * 5;
      stabilityBase -= policies.filter(p=>p.isActive && p.id === 'free_media').length * 2;
      stabilityBase -= (newState.oppositionStrength / 100) * (newState.oppositionDiscontent / 100) * 20; 
      stabilityBase -= newState.unemployment / 10;
      stabilityBase += newState.gdp > prevState.gdp ? 2 : -2;
      stabilityBase += (newState.governmentConfidence - 50) / 10; // Confidence affects stability

      newState.politicalStability = Math.max(0, Math.min(100, stabilityBase));
      
      // Government Confidence
      let confidenceChange = (newState.politicalStability - prevState.politicalStability) / 5;
      confidenceChange += (newState.popularLoyalty - prevState.popularLoyalty) / 10;
      if (newState.gdp < prevState.gdp) confidenceChange -= 2;
      if (gameOverMessage) confidenceChange = -50; // Major hit if game over condition triggered last turn
      newState.governmentConfidence = Math.max(0, Math.min(100, newState.governmentConfidence + confidenceChange));


      // Advisor Advice (add to news feed)
      advisors.forEach(adv => {
          if (typeof adv.getAdvice === 'function') { 
            const advice = adv.getAdvice(newState, budget, policies, laws, politicalParties, newState.tradeUnions);
            if (advice.priority === 'high' || (advice.priority === 'medium' && Math.random() < 0.5) || (advice.priority === 'low' && Math.random() < 0.2)) {
               setNewsFeed(prevNews => [
                  { id: `advisor-${adv.id}-${newState.year}`, content: '', contentAr: `${adv.nameAr} (${adv.roleAr}): ${advice.messageAr}`, type: 'advisor'},
                  ...prevNews.slice(0,14)
              ]);
            }
          } else {
            console.warn(`Advisor ${adv.id} is missing getAdvice function.`);
          }
      });
      
      const potentialEvents = GAME_EVENTS_DEFINITIONS.filter(event => 
        event.triggerCondition 
          ? event.triggerCondition(newState, budget, politicalParties, newState.tradeUnions) 
          : Math.random() < 0.15
      );
      if (potentialEvents.length > 0 && !currentEvent && !gameOverMessage) {
        setCurrentEvent(potentialEvents[Math.floor(Math.random() * potentialEvents.length)]);
      }
      
      setNewsFeed(prevNews => {
        const randomNewsBase = NEWS_ITEMS_BASE[Math.floor(Math.random() * NEWS_ITEMS_BASE.length)];
        const newNewsItem: NewsItem = {...randomNewsBase, id: newState.year.toString() + Math.random().toString() };
        return [newNewsItem, ...prevNews.slice(0, 14)];
      });
      
      if (!gameOverMessage && newState.year !== INITIAL_YEAR && (newState.year - INITIAL_YEAR) % 4 === 0) {
        if (newState.popularLoyalty < 40 || newState.politicalStability < 30 || newState.governmentConfidence < 35) {
          setGameOverMessage(`خسرت الانتخابات في عام ${newState.year} بسبب انخفاض الدعم الشعبي أو عدم الاستقرار أو فقدان الثقة الحكومية!`);
        } else {
           setNewsFeed(prev => [{id: `election-${newState.year}`, contentAr: `تهانينا! لقد فزت في انتخابات عام ${newState.year}!`, content: `Congratulations! You've won the ${newState.year} elections!`, type: 'success'}, ...prev]);
           newState.politicalCapital += 20;
           newState.governmentConfidence = Math.min(100, newState.governmentConfidence + 15);
        }
      }
      
      if (!gameOverMessage) {
        if (newState.money <= 0 && newState.debt > prevState.gdp * 2 && prevState.gdp > 0) {
          setGameOverMessage("انهيار اقتصادي! أفلست أمتك.");
        } else if (newState.popularLoyalty <= 0) {
          setGameOverMessage("ثورة شعبية! أطاح الشعب بحكومتك.");
        } else if (newState.militaryLoyalty <= 0) {
          setGameOverMessage("انقلاب عسكري! استولت القوات المسلحة على السلطة.");
        } else if (newState.politicalStability <= 0) {
          setGameOverMessage("فوضى! انزلقت الأمة إلى الفوضى.");
        }
      }
      // Update the main tradeUnions state outside of setCountryState, after all calculations.
      // This is because setCountryState might not immediately reflect the newState.tradeUnions for the event trigger check.
      setTradeUnions(newState.tradeUnions);
      return newState;
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [budget, taxRates, policies, laws, currentEvent, currentTechProgress, gameOverMessage, politicalParties, advisors]);

  useEffect(() => {
    setIsGamePaused(!!gameOverMessage || !!currentEvent);
  }, [gameOverMessage, currentEvent]);

  useEffect(() => {
    if (isGamePaused) {
      if (gameTickIntervalRef.current) {
        clearInterval(gameTickIntervalRef.current);
        gameTickIntervalRef.current = null;
      }
      return;
    }

    if (!gameTickIntervalRef.current) {
      gameTickIntervalRef.current = window.setInterval(() => {
        setCountryState(prev => {
          let newMonth = prev.currentMonth + 1;
          let newYear = prev.year;
          if (newMonth >= 12) {
            newMonth = 0;
            newYear += 1;
          }
          return { ...prev, currentMonth: newMonth, year: newYear };
        });
      }, MONTH_DURATION_MS); 
    }

    return () => {
      if (gameTickIntervalRef.current) {
        clearInterval(gameTickIntervalRef.current);
        gameTickIntervalRef.current = null;
      }
    };
  }, [isGamePaused]);
  
  useEffect(() => {
    if (countryState.year > lastProcessedYearRef.current && countryState.currentMonth === 0) {
        processYearEndLogic();
        lastProcessedYearRef.current = countryState.year;
    }
  }, [countryState.year, countryState.currentMonth, processYearEndLogic]);


  const handlePolicyToggle = (policyId: string) => {
    const policy = policies.find(p => p.id === policyId);
    if (!policy || countryState.politicalCapital < policy.costPoliticalCapitalToggle || isGamePaused) return;
    if (typeof policy.effects !== 'function') {
        console.warn(`Policy ${policyId} is missing effects function.`);
        return;
    }

    setCountryState(prev => ({...prev, politicalCapital: prev.politicalCapital - policy.costPoliticalCapitalToggle}));
    const immediateEffect = policy.effects(countryState);
    setCountryState(prev => ({...prev, ...immediateEffect}));
    setPolicies(prevPolicies =>
      prevPolicies.map(p =>
        p.id === policyId ? { ...p, isActive: !p.isActive } : p
      )
    );
  };

  const handlePassLaw = (lawId: string) => {
    const law = laws.find(l => l.id === lawId);
    if (!law || law.isPassed || isGamePaused) return;
    if (typeof law.effects !== 'function') {
        console.warn(`Law ${lawId} is missing effects function.`);
        return;
    }

    let baseSupport = politicalParties.reduce((acc, party) => {
        let partySupportFactor = 0.5; 
        if ((law.id.includes("health") || law.id.includes("education")) && (party.ideology === "Liberal" || party.ideology === "Socialist")) partySupportFactor = 0.8;
        if (law.id.includes("research") && party.ideology === "Liberal") partySupportFactor = 0.7;
        if (law.id.includes("defense") && (party.ideology === "Conservative" || party.ideology === "Nationalist")) partySupportFactor = 0.8;
        if (law.opposingIdeologies?.includes(party.ideology)) partySupportFactor *= (1 - (countryState.oppositionDiscontent / 150));
        
        return acc + (party.support * partySupportFactor);
    }, 0);
    
    const effectiveSupport = Math.min(100, 
        (baseSupport * 0.7) + 
        (countryState.politicalStability / 3) + 
        (countryState.politicalCapital / 15) - 
        (countryState.oppositionStrength / 10) +
        (countryState.governmentConfidence / 10) // Higher confidence helps pass laws
    );


    if (countryState.money >= law.costMoney &&
        countryState.politicalCapital >= law.costPoliticalCapital &&
        countryState.techLevel >= law.techRequirement &&
        effectiveSupport >= law.parliamentarySupportThreshold) {
      
      const lawEffects = law.effects(countryState);
      setCountryState(prev => ({
        ...prev,
        money: prev.money - law.costMoney,
        politicalCapital: prev.politicalCapital - law.costPoliticalCapital,
        governmentConfidence: Math.min(100, prev.governmentConfidence + 2), // Passing laws slightly boosts confidence
        ...lawEffects
      }));
      setLaws(prevLaws => prevLaws.map(l => l.id === lawId ? { ...l, isPassed: true } : l));
      setNewsFeed(prev => [{id: `law-${lawId}`, contentAr: `تم تمرير '${law.nameAr}' بنجاح!`, content: `The '${law.name}' has been successfully passed!`, type: 'success'}, ...prev.slice(0,14)]);
    } else {
        let reasonAr = "";
        if(countryState.money < law.costMoney) reasonAr="أموال غير كافية";
        else if(countryState.politicalCapital < law.costPoliticalCapital) reasonAr="رأس مال سياسي غير كافٍ";
        else if(countryState.techLevel < law.techRequirement) reasonAr="مستوى التكنولوجيا منخفض جدًا";
        else if(effectiveSupport < law.parliamentarySupportThreshold) reasonAr=`دعم برلماني غير كافٍ (المطلوب ${law.parliamentarySupportThreshold}%. الحالي ${effectiveSupport.toFixed(1)}%)`;
        setCountryState(prev => ({...prev, governmentConfidence: Math.max(0, prev.governmentConfidence - 3)})); // Failing to pass laws hurts confidence
        setNewsFeed(prev => [{id: `lawfail-${lawId}`, contentAr: `فشل تمرير '${law.nameAr}'. السبب: ${reasonAr}.`, content: `Failed to pass '${law.name}'. Reason: ${reasonAr}.`, type: 'warning'}, ...prev.slice(0,14)]);
    }
  };

  const handleTrade = (partnerId: string, resource: TradeResource, amount: number, action: 'buy' | 'sell') => {
    if (isGamePaused) return;
    const partner = tradePartners.find(p => p.id === partnerId);
    if (!partner) return;

    let price = 0;
    let availableAmount = Infinity;
    const resourceNameAr = TRADE_RESOURCE_LABELS_AR[resource];

    if (action === 'buy') {
        const item = partner.sells[resource];
        if(!item) {
          setNewsFeed(prev => [{id: `tradefail-${partnerId}-${resource}`, contentAr: `${partner.nameAr} لا تبيع ${resourceNameAr}.`, content:`${partner.name} does not sell ${resource}.`, type: 'warning'}, ...prev.slice(0,14)]);
          return;
        }
        price = item.price;
        availableAmount = item.availability;
        if (amount <=0) return;
        if (amount > availableAmount) {
            setNewsFeed(prev => [{id: `tradefail-${partnerId}-${resource}`, contentAr: `${partner.nameAr} لديها فقط ${availableAmount} وحدة من ${resourceNameAr}.`, content:`${partner.name} only has ${availableAmount} units of ${resource}.`, type: 'warning'}, ...prev.slice(0,14)]);
            return;
        }
        if (countryState.money < amount * price) {
            setNewsFeed(prev => [{id: `tradefail-${partnerId}-${resource}`, contentAr: `لا يوجد مال كافٍ لشراء ${amount} وحدة من ${resourceNameAr}.`, content:`Not enough money to buy ${amount} units of ${resource}.`, type: 'warning'}, ...prev.slice(0,14)]);
            return;
        }
        setCountryState(prev => ({
            ...prev,
            money: prev.money - (amount * price),
            nationalResources: { ...prev.nationalResources, [resource]: prev.nationalResources[resource] + amount }
        }));
        setTradePartners(prevPartners => prevPartners.map(p => p.id === partnerId ? {...p, sells: {...p.sells, [resource]: {...item, availability: item.availability - amount}}, relation: Math.min(100, p.relation + 1)} : p));

    } else { 
        const item = partner.buys[resource];
         if(!item) {
          setNewsFeed(prev => [{id: `tradefail-${partnerId}-${resource}`, contentAr: `${partner.nameAr} لا تشتري ${resourceNameAr}.`, content:`${partner.name} does not buy ${resource}.`, type: 'warning'}, ...prev.slice(0,14)]);
          return;
        }
        price = item.price;
        const demandAmount = item.demand;
        if (amount <=0) return;
         if (amount > demandAmount) {
            setNewsFeed(prev => [{id: `tradefail-${partnerId}-${resource}`, contentAr: `${partner.nameAr} تريد شراء ${demandAmount} وحدة فقط من ${resourceNameAr}.`, content:`${partner.name} only wants to buy ${demandAmount} units of ${resource}.`, type: 'warning'}, ...prev.slice(0,14)]);
            return;
        }
        if (countryState.nationalResources[resource] < amount) {
             setNewsFeed(prev => [{id: `tradefail-${partnerId}-${resource}`, contentAr: `لا يوجد ما يكفي من ${resourceNameAr} للبيع.`, content:`Not enough ${resource} to sell.`, type: 'warning'}, ...prev.slice(0,14)]);
            return;
        }
        setCountryState(prev => ({
            ...prev,
            money: prev.money + (amount * price),
            nationalResources: { ...prev.nationalResources, [resource]: prev.nationalResources[resource] - amount }
        }));
        setTradePartners(prevPartners => prevPartners.map(p => p.id === partnerId ? {...p, buys: {...p.buys, [resource]: {...item, demand: item.demand - amount}}, relation: Math.min(100, p.relation + 1)} : p));
    }
    const actionAr = action === 'buy' ? 'شراء' : 'بيع';
    const prepositionAr = action === 'buy' ? 'من' : 'إلى';
    setNewsFeed(prev => [{id: `trade-${partnerId}-${resource}`, contentAr: `تم بنجاح ${actionAr} ${amount} ${resourceNameAr} ${prepositionAr} ${partner.nameAr}.`, content: `Successfully ${action === 'buy' ? 'bought' : 'sold'} ${amount} ${resource} ${action === 'buy' ? 'from' : 'to'} ${partner.name}.`, type: 'success'}, ...prev.slice(0,14)]);
  };
  
  const handleDiplomacy = (partnerId: string, actionType: 'improve_relations' | 'decrease_relations') => {
    if (isGamePaused) return;
    const costPC = 10;
    if(countryState.politicalCapital < costPC) {
        setNewsFeed(prev => [{id: `diplofail-${partnerId}`, contentAr: `لا يوجد رأس مال سياسي كافٍ للعمل الدبلوماسي.`, content: `Not enough political capital for diplomatic action.`, type: 'warning'}, ...prev.slice(0,14)]);
        return;
    }

    setCountryState(prev => ({...prev, politicalCapital: prev.politicalCapital - costPC}));
    setTradePartners(prevPartners => prevPartners.map(p => {
        if (p.id === partnerId) {
            const change = actionType === 'improve_relations' ? 5 : -5;
            return {...p, relation: Math.max(0, Math.min(100, p.relation + change))};
        }
        return p;
    }));
    const actionStatusAr = actionType === 'improve_relations' ? 'تحسنت' : 'تدهورت';
    setNewsFeed(prev => [{id: `diplo-${partnerId}`, contentAr: `العلاقات مع ${tradePartners.find(p=>p.id===partnerId)?.nameAr} قد ${actionStatusAr}.`, content: `Relations with ${tradePartners.find(p=>p.id===partnerId)?.name} ${actionType === 'improve_relations' ? 'improved' : 'worsened'}.`, type: 'info'}, ...prev.slice(0,14)]);
  };

  const handleEventOption = (effectsCallback: (state: CountryState) => Partial<CountryState>) => {
    if (typeof effectsCallback !== 'function') {
        console.warn('Event option is missing effects function.');
        setCurrentEvent(null);
        return;
    }
    const effects = effectsCallback(countryState); // Calculate effects based on current state
    setCountryState(prev => ({ ...prev, ...effects }));
    
    // If effects include changes to tradeUnions, update the tradeUnions state
    if (effects.tradeUnions) {
        setTradeUnions(effects.tradeUnions);
    }
    setCurrentEvent(null);
  };

  const restartGame = () => {
    setCountryState(INITIAL_COUNTRY_STATE);
    setBudget(INITIAL_BUDGET_ALLOCATION);
    setTaxRates(INITIAL_TAX_RATES);
    setPolicies(() => POLICIES_DEFINITIONS.map(p => ({ ...p })));
    setLaws(() => LAWS_DEFINITIONS.map(l => ({ ...l })));
    setTradePartners(() => NATIONS_DEFINITIONS.map(n => ({...n})));
    setPoliticalParties(() => POLITICAL_PARTIES_DEFINITIONS.map(p => ({ ...p })));
    setAdvisors(() => ADVISORS_DEFINITIONS.map(a => ({ ...a })));
    setTradeUnions(() => TRADE_UNIONS_DEFINITIONS.map(tu => ({ ...tu })));
    setCurrentEvent(null);
    setGameOverMessage(null);
    setNewsFeed(NEWS_ITEMS_BASE.slice(0,5).map(n => ({...n, id: Math.random().toString() })));
    setCurrentTechProgress(0);
    setActiveTab(GameTab.Dashboard);
    lastProcessedYearRef.current = INITIAL_COUNTRY_STATE.year -1; 
  };
  
  useEffect(() => {
    if (countryState.year === INITIAL_YEAR && countryState.currentMonth === 0 && lastProcessedYearRef.current < INITIAL_YEAR) return; 
    if (countryState.currentMonth !==0) return;

    setPoliticalParties(prevParties => {
      let updatedParties = prevParties.map(party => {
        let supportChange = 0;
        if(party.ideology === "Liberal" && countryState.popularLoyalty > 60) supportChange +=1;
        if(party.ideology === "Conservative" && countryState.militaryLoyalty > 60) supportChange +=1;
        if(party.ideology === "Socialist" && countryState.unemployment < 5 && laws.some(l => l.id === 'universal_healthcare' && l.isPassed)) supportChange +=1.5;
        if(party.ideology === "Nationalist" && countryState.politicalStability > 60) supportChange +=1;
        
        policies.forEach(pol => {
            if(pol.isActive){
                if(pol.id === 'free_media' && party.ideology === 'Liberal') supportChange += 0.5;
                if(pol.id === 'internet_censorship' && party.ideology === 'Conservative') supportChange += 0.5;
            }
        });

        let newSupport = party.support + supportChange - 0.5; 
        if (countryState.oppositionDiscontent > 50 && (party.ideology === "Populist" || (party.ideology === "Liberal" && policies.some(p => p.id === 'internet_censorship' && p.isActive)))) {
            newSupport += 1.5; 
        }
        if (countryState.governmentConfidence < 40 && (party.ideology === "Populist" || party.ideology === "Nationalist" )) { // Low confidence benefits opposition/nationalists
            newSupport += 1;
        }
        if (countryState.governmentConfidence > 70 && (party.ideology === "Conservative" || (party.ideology === "Liberal" && !policies.some(p => p.id === 'internet_censorship' && p.isActive) ) )) { // High confidence benefits status quo / moderate liberals
            newSupport += 0.5;
        }


        return {...party, support: Math.max(5, Math.min(60, newSupport))};
      });
      
      const totalSupport = updatedParties.reduce((sum, p) => sum + p.support, 0);
      if (totalSupport === 0) return updatedParties; 
      return updatedParties.map(p => ({...p, support: Math.round((p.support / totalSupport) * 100) }));
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [countryState.year]); // Dependency on countryState.year for annual update


  if (gameOverMessage) {
    return <GameOverScreen message={gameOverMessage} onRestart={restartGame} finalState={countryState} />;
  }

  const renderTabContent = () => {
    switch (activeTab) {
      case GameTab.Dashboard:
        return <DashboardTab countryState={countryState} budget={budget} taxRates={taxRates} policies={policies} laws={laws} techProgress={currentTechProgress} />;
      case GameTab.Economy:
        return <EconomyTab countryState={countryState} taxRates={taxRates} setTaxRates={setTaxRates} />;
      case GameTab.Budget:
        return <BudgetTab budget={budget} setBudget={setBudget} money={countryState.money} />;
      case GameTab.Policies:
        return <PoliciesTab policies={policies} onTogglePolicy={handlePolicyToggle} politicalCapital={countryState.politicalCapital} />;
      case GameTab.Laws:
        return <LawsTab laws={laws} onPassLaw={handlePassLaw} countryState={countryState} politicalParties={politicalParties} />;
      case GameTab.Trade:
        return <TradeTab countryState={countryState} tradePartners={tradePartners} onTrade={handleTrade} />;
      case GameTab.InternalAffairs:
        return <InternalAffairsTab politicalParties={politicalParties} countryState={countryState} tradeUnions={tradeUnions} />;
      case GameTab.ExternalAffairs:
        return <ExternalAffairsTab tradePartners={tradePartners} onDiplomacy={handleDiplomacy} politicalCapital={countryState.politicalCapital} />;
      case GameTab.Cabinet:
        return <CabinetTab advisors={advisors} countryState={countryState} budget={budget} policies={policies} laws={laws} politicalParties={politicalParties} tradeUnions={tradeUnions}/>;
      default:
        return null;
    }
  };

  return (
    <div className="flex flex-col h-screen bg-slate-900 text-slate-100">
      <TopBar countryState={countryState} isPaused={isGamePaused} />
      <div className="flex flex-1 overflow-hidden">
        <SideBar activeTab={activeTab} setActiveTab={setActiveTab} />
        <main className="flex-1 p-6 overflow-y-auto bg-slate-800">
          {renderTabContent()}
        </main>
      </div>
      <NewsTicker newsItems={newsFeed} />
      {(() => {
        if (currentEvent) {
            let resolvedDescriptionAr: string;
            if (typeof currentEvent.descriptionAr === 'function') {
                const descArFn = currentEvent.descriptionAr;
                resolvedDescriptionAr = descArFn(countryState);
            } else {
                resolvedDescriptionAr = currentEvent.descriptionAr;
            }

            let resolvedDescription: string;
             if (typeof currentEvent.description === 'function') {
                const descFn = currentEvent.description;
                resolvedDescription = descFn(countryState);
            } else {
                resolvedDescription = currentEvent.description;
            }

            const eventPropsForModal: GameEvent = { 
                ...currentEvent, 
                description: resolvedDescription,
                descriptionAr: resolvedDescriptionAr 
            };
            
            return (
                <EventModal
                    event={eventPropsForModal}
                    onOptionClick={handleEventOption}
                    onClose={() => { setCurrentEvent(null); }}
                />
            );
        }
        return null;
      })()}
    </div>
  );
};

export default App;
