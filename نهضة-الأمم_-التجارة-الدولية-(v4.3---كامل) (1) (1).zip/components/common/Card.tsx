
import React from 'react';

interface CardProps {
  title?: string;
  children: React.ReactNode;
  className?: string;
  titleClassName?: string;
}

const Card: React.FC<CardProps> = ({ title, children, className = '', titleClassName = '' }) => {
  return (
    <div className={`bg-slate-700 shadow-lg rounded-lg p-4 sm:p-6 ${className}`}>
      {title && (
        <h3 className={`text-lg font-semibold mb-3 text-sky-400 border-b border-slate-600 pb-2 ${titleClassName}`}>
          {title}
        </h3>
      )}
      {children}
    </div>
  );
};

export default Card;
