import React from 'react';
import { NewsItem, NEWS_ITEM_TYPE_LABELS_AR } from '../types';
import { FaInfoCircle, FaExclamationTriangle, FaCheckCircle, FaMinusCircle, FaUserTie } from 'react-icons/fa';


interface NewsTickerProps {
  newsItems: NewsItem[];
}

const SimpleNewsDisplay: React.FC<NewsTickerProps> = ({ newsItems }) => {
  if (!newsItems || newsItems.length === 0) {
    return null;
  }
   const getNewsStyle = (type: NewsItem['type']): { color: string; icon: React.ReactNode } => {
    switch(type) {
        case 'success': return { color: 'text-green-400', icon: <FaCheckCircle className="mr-1 rtl:ml-1"/> };
        case 'warning': return { color: 'text-red-400', icon: <FaExclamationTriangle className="mr-1 rtl:ml-1"/> };
        case 'info': return { color: 'text-sky-400', icon: <FaInfoCircle className="mr-1 rtl:ml-1"/> };
        case 'advisor': return { color: 'text-purple-400', icon: <FaUserTie className="mr-1 rtl:ml-1"/> };
        default: return { color: 'text-slate-300', icon: <FaMinusCircle className="mr-1 rtl:ml-1"/> };
    }
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-slate-800 border-t border-slate-700 h-auto max-h-24 p-2 overflow-y-auto shadow-lg z-10 flex flex-col-reverse space-y-reverse space-y-1">
        {newsItems.slice(0, 4).map((item, index) => {
          const style = getNewsStyle(item.type);
          return (
            <p key={`${item.id}-${index}`} className={`text-xs ${style.color} truncate flex items-center`}>
              {style.icon}
              <span className="font-semibold ml-1 rtl:mr-0 rtl:ml-1">{NEWS_ITEM_TYPE_LABELS_AR[item.type]}:</span> {item.contentAr || item.content}
            </p>
          );
        })}
    </div>
  );
}

export default SimpleNewsDisplay;