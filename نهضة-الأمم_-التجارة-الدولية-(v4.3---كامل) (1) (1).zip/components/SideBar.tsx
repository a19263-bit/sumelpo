import React from 'react';
import { GameTab, GAME_TAB_LABELS } from '../types';
import { FaTachometerAlt, FaPiggyBank, FaFileContract, FaGavel, FaExchangeAlt, FaUsersCog, FaGlobeAmericas, FaLandmark, FaBriefcase as FaCabinetIcon } from 'react-icons/fa'; // Changed FaLandmark for Policies, Using FaBriefcase for Cabinet

interface SideBarProps {
  activeTab: GameTab;
  setActiveTab: (tab: GameTab) => void;
}

interface NavItemProps {
  label: string;
  icon: React.ReactNode;
  isActive: boolean;
  onClick: () => void;
}

const NavItem: React.FC<NavItemProps> = ({ label, icon, isActive, onClick }) => (
  <button
    onClick={onClick}
    className={`flex items-center space-x-3 rtl:space-x-reverse w-full px-4 py-3 text-sm font-medium rounded-md transition-colors duration-150
                ${isActive ? 'bg-sky-600 text-white shadow-lg' : 'text-slate-300 hover:bg-slate-700 hover:text-white'}`}
    aria-current={isActive ? 'page' : undefined}
  >
    <span className="ml-0 rtl:ml-3">{icon}</span>
    <span>{label}</span>
  </button>
);

const SideBar: React.FC<SideBarProps> = ({ activeTab, setActiveTab }) => {
  const navItemsConfig = [
    { tab: GameTab.Dashboard, icon: <FaTachometerAlt /> },
    { tab: GameTab.Cabinet, icon: <FaCabinetIcon /> }, // Added Cabinet
    { tab: GameTab.Economy, icon: <FaPiggyBank /> },
    { tab: GameTab.Budget, icon: <FaFileContract /> },
    { tab: GameTab.Policies, icon: <FaLandmark /> }, // Changed from FaScroll to FaLandmark for consistency
    { tab: GameTab.Laws, icon: <FaGavel /> },
    { tab: GameTab.Trade, icon: <FaExchangeAlt /> },
    { tab: GameTab.InternalAffairs, icon: <FaUsersCog /> },
    { tab: GameTab.ExternalAffairs, icon: <FaGlobeAmericas /> },
  ];

  return (
    <aside className="w-64 bg-slate-800 p-4 space-y-2 border-l border-slate-700 rtl:border-r rtl:border-l-0 overflow-y-auto">
      <nav className="space-y-1">
        {navItemsConfig.map(item => (
          <NavItem
            key={item.tab}
            label={GAME_TAB_LABELS[item.tab]}
            icon={item.icon}
            isActive={activeTab === item.tab}
            onClick={() => setActiveTab(item.tab)}
          />
        ))}
      </nav>
    </aside>
  );
};

export default SideBar;