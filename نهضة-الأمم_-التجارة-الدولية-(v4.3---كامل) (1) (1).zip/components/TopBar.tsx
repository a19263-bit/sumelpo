
import React from 'react';
import { CountryState } from '../types';
import { FaCalendarAlt, FaMoneyBillWave, FaUsers, FaShieldAlt, FaFlask, FaBalanceScale, FaLandmark, FaMoon, FaPauseCircle, FaPlayCircle } from 'react-icons/fa';
import { MONTH_NAMES_AR } from '../constants';

interface TopBarProps {
  countryState: CountryState;
  isPaused: boolean;
}

const StatDisplay: React.FC<{ icon: React.ReactNode, label: string, value: string | number, color?: string, tooltip?: string }> = ({ icon, label, value, color = 'text-slate-300', tooltip }) => (
  <div className="flex items-center space-x-2 rtl:space-x-reverse px-3 py-1 bg-slate-700 rounded shadow min-w-[120px]" title={tooltip}>
    <span className={`${color} text-lg`}>{icon}</span>
    <div>
      <span className="text-xs text-slate-400 block">{label}</span>
      <span className={`text-sm font-semibold ${color}`}>{value}</span>
    </div>
  </div>
);


const TopBar: React.FC<TopBarProps> = ({ countryState, isPaused }) => {
  const formatMoney = (amount: number) => {
    const absAmount = Math.abs(amount);
    const sign = amount < 0 ? "-" : "";
    if (absAmount >= 1000000000) return `${sign}${(absAmount / 1000000000).toFixed(2)} مليار`;
    if (absAmount >= 1000000) return `${sign}${(absAmount / 1000000).toFixed(2)} مليون`;
    if (absAmount >= 1000) return `${sign}${(absAmount / 1000).toFixed(2)} ألف`;
    return `${sign}${absAmount.toFixed(0)}`;
  };

  const monthName = MONTH_NAMES_AR[countryState.currentMonth];

  return (
    <header className="bg-slate-800 text-white p-3 shadow-md flex justify-between items-center border-b border-slate-700">
      <h1 className="text-xl font-bold text-sky-400">نهضة الأمم <span className="text-xs text-slate-400">V4.3</span></h1>
      <div className="flex items-center space-x-3 rtl:space-x-reverse overflow-x-auto pb-2 sm:overflow-visible sm:pb-0">
        <StatDisplay icon={<FaCalendarAlt />} label="العام" value={countryState.year} />
        <StatDisplay icon={<FaMoon />} label="الشهر" value={monthName} />
        <StatDisplay 
            icon={<FaMoneyBillWave />} 
            label="الخزينة" 
            value={`${formatMoney(countryState.money)}`} 
            color={countryState.money < 0 ? 'text-red-400' : 'text-green-400'} 
            tooltip={`الدين: ${formatMoney(countryState.debt)}`}
        />
        <StatDisplay icon={<FaUsers />} label="ولاء الشعب" value={`${countryState.popularLoyalty.toFixed(0)}%`} color={countryState.popularLoyalty < 40 ? 'text-red-400' : 'text-sky-400'} />
        <StatDisplay icon={<FaShieldAlt />} label="ولاء الجيش" value={`${countryState.militaryLoyalty.toFixed(0)}%`} color={countryState.militaryLoyalty < 40 ? 'text-red-400' : 'text-amber-400'} />
        <StatDisplay icon={<FaBalanceScale />} label="الاستقرار" value={`${countryState.politicalStability.toFixed(0)}%`} color={countryState.politicalStability < 40 ? 'text-red-400' : 'text-indigo-400'} />
        <StatDisplay icon={<FaFlask />} label="مستوى التقنية" value={countryState.techLevel} />
        <StatDisplay icon={<FaLandmark />} label="رأس المال السياسي" value={countryState.politicalCapital} />
      </div>
      <div className="flex items-center px-3 py-1 text-sm">
        {isPaused ? (
            <div title="اللعبة متوقفة مؤقتًا" className="flex items-center space-x-2 rtl:space-x-reverse text-red-400">
                <FaPauseCircle className="text-2xl animate-pulse" /> 
                <span>متوقفة</span>
            </div>
        ) : (
            <div title="اللعبة قيد التشغيل" className="flex items-center space-x-2 rtl:space-x-reverse text-green-400">
                <FaPlayCircle className="text-2xl" />
                <span>جارية</span>
            </div>
        )}
      </div>
    </header>
  );
};

export default TopBar;
