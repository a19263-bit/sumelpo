
import React from 'react';
import { GameEvent, CountryState } from '../types';
import Button from './common/Button';

interface EventModalProps {
  event: GameEvent;
  onOptionClick: (effects: (state: CountryState) => Partial<CountryState>) => void;
  onClose: () => void;
}

const EventModal: React.FC<EventModalProps> = ({ event, onOptionClick, onClose }) => {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-50 transition-opacity duration-300 ease-in-out">
      <div className="bg-slate-800 p-6 rounded-lg shadow-2xl max-w-lg w-full transform transition-all duration-300 ease-in-out scale-100">
        <div className="flex justify-between items-center mb-4">
            <h3 className="text-2xl font-semibold text-sky-400">{event.titleAr}</h3>
            <button onClick={onClose} className="text-slate-400 hover:text-slate-200 text-2xl">&times;</button>
        </div>
        
        {event.imageUrl && (
          <img src={event.imageUrl} alt={event.titleAr} className="w-full h-48 object-cover rounded-md mb-4" />
        )}
        <p className="text-slate-300 mb-6 whitespace-pre-wrap">{event.descriptionAr}</p>
        <div className="space-y-3">
          {event.options.map((option, index) => (
            <Button
              key={index}
              onClick={() => onOptionClick(option.effects)}
              variant="primary"
              className="w-full"
            >
              {option.textAr}
            </Button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default EventModal;
