
import React from 'react';
import { CountryState } from '../types';
import Button from './common/Button';
import Card from './common/Card';

interface GameOverScreenProps {
  message: string;
  onRestart: () => void;
  finalState: CountryState;
}

const GameOverScreen: React.FC<GameOverScreenProps> = ({ message, onRestart, finalState }) => {
  const formatMoney = (amount: number) => {
    const absAmount = Math.abs(amount);
    const sign = amount < 0 ? "-" : "";
    if (absAmount >= 1000000000) return `${sign}${(absAmount / 1000000000).toFixed(2)} مليار`;
    if (absAmount >= 1000000) return `${sign}${(absAmount / 1000000).toFixed(2)} مليون`;
    if (absAmount >= 1000) return `${sign}${(absAmount / 1000).toFixed(2)} ألف`;
    return `${sign}${absAmount.toFixed(0).toString()}`;
  };
  return (
    <div className="fixed inset-0 bg-slate-900 bg-opacity-95 flex flex-col items-center justify-center p-4 z-50 text-center">
      <Card title="انتهت اللعبة" className="max-w-md w-full">
        <h2 className="text-3xl font-bold text-red-500 mb-4">انتهى عهدك!</h2>
        <p className="text-xl text-slate-300 mb-6">{message}</p>
        
        <div className="text-right rtl:text-right text-sm text-slate-400 mb-6 border-t border-slate-700 pt-4">
            <h4 className="font-semibold text-slate-200 mb-2">الحالة النهائية للأمة (العام {finalState.year}):</h4>
            <ul className="list-disc list-inside pr-5 rtl:pl-5 rtl:pr-0 space-y-1">
                <li>الخزينة: {formatMoney(finalState.money)}</li>
                <li>الدين: {formatMoney(finalState.debt)}</li>
                <li>الولاء الشعبي: {finalState.popularLoyalty.toFixed(0)}%</li>
                <li>الولاء العسكري: {finalState.militaryLoyalty.toFixed(0)}%</li>
                <li>الاستقرار السياسي: {finalState.politicalStability.toFixed(0)}%</li>
                <li>مستوى التكنولوجيا: {finalState.techLevel}</li>
            </ul>
        </div>

        <Button onClick={onRestart} variant="primary" size="lg">
          حاول مرة أخرى
        </Button>
      </Card>
    </div>
  );
};

export default GameOverScreen;
