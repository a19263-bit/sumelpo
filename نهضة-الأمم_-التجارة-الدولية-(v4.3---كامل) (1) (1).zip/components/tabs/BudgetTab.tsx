
import React from 'react';
import { BudgetAllocation } from '../../types';
import Card from '../common/Card';

interface BudgetTabProps {
  budget: BudgetAllocation;
  setBudget: React.Dispatch<React.SetStateAction<BudgetAllocation>>;
  money: number;
}

const BudgetTab: React.FC<BudgetTabProps> = ({ budget, setBudget, money }) => {
  const totalAllocated = Object.values(budget).reduce((sum, val) => sum + val, 0);

  const handleBudgetChange = (sector: keyof BudgetAllocation, value: string) => {
    const numValue = parseInt(value, 10);
    if (!isNaN(numValue) && numValue >= 0 && numValue <= 100) { // Max per sector 100, though sum is 100
      setBudget(prev => {
        const newBudget = { ...prev, [sector]: numValue };
        return newBudget;
      });
    }
  };
  
  const budgetCategories: { key: keyof BudgetAllocation; labelAr: string; descriptionAr: string }[] = [
      { key: 'education', labelAr: 'التعليم', descriptionAr: 'يحسن نمو التكنولوجيا والولاء الشعبي.' },
      { key: 'health', labelAr: 'الرعاية الصحية', descriptionAr: 'يزيد الولاء الشعبي وإنتاجية القوى العاملة.' },
      { key: 'defense', labelAr: 'الدفاع', descriptionAr: 'يعزز الولاء العسكري والأمن القومي.' },
      { key: 'infrastructure', labelAr: 'البنية التحتية', descriptionAr: 'يحفز النمو الاقتصادي (الناتج المحلي الإجمالي).' },
      { key: 'research', labelAr: 'البحث العلمي', descriptionAr: 'يسرع التقدم التكنولوجي.' },
      { key: 'socialWelfare', labelAr: 'الرعاية الاجتماعية', descriptionAr: 'يدعم المواطنين ويزيد الولاء الشعبي ولكنه قد يكون مكلفًا.' },
  ];
  
  const formatMoney = (amount: number) => {
    const absAmount = Math.abs(amount);
    const sign = amount < 0 ? "-" : "";
    if (absAmount >= 1000000000) return `${sign}${(absAmount / 1000000000).toFixed(2)} مليار`;
    if (absAmount >= 1000000) return `${sign}${(absAmount / 1000000).toFixed(2)} مليون`;
    if (absAmount >= 1000) return `${sign}${(absAmount / 1000).toFixed(2)} ألف`;
    return `${sign}${absAmount.toFixed(0)}`;
  };


  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-semibold text-sky-400">تخصيص الميزانية السنوية</h2>
      
      <Card title="تخصيص الإنفاق">
        <div className="mb-4 p-3 bg-slate-800 rounded">
          <p className="text-lg">
            إجمالي المخصص: <span className={`font-bold ${totalAllocated > 100 ? 'text-red-400' : 'text-green-400'}`}>{totalAllocated}%</span>
          </p>
          {totalAllocated > 100 && (
            <p className="text-sm text-red-400">تحذير: تخصيص الميزانية يتجاوز 100%. سيتم تحديد سقف للإنفاق أو تكبد المزيد من الديون.</p>
          )}
           {totalAllocated < 100 && (
            <p className="text-sm text-amber-400">ملاحظة: تخصيص الميزانية أقل من 100%. الأموال غير المخصصة تبقى في الخزينة.</p>
          )}
          <p className="text-xs text-slate-400">خصص نسبًا مئوية من الإنفاق الوطني لمختلف القطاعات. يجب أن يكون الإجمالي مثاليًا 100%.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {budgetCategories.map(cat => (
            <div key={cat.key} className="bg-slate-600 p-4 rounded-md shadow">
              <label htmlFor={cat.key} className="block text-md font-medium text-slate-200 capitalize mb-1">
                {cat.labelAr}: <span className="text-sky-400 font-bold">{budget[cat.key]}%</span>
              </label>
              <input
                type="range"
                id={cat.key}
                min="0"
                max="50" // Max percentage for a single sector (can be adjusted)
                value={budget[cat.key]}
                onChange={(e) => handleBudgetChange(cat.key, e.target.value)}
                className="w-full h-2 bg-slate-500 rounded-lg appearance-none cursor-pointer accent-sky-500"
              />
              <p className="text-xs text-slate-400 mt-1">{cat.descriptionAr}</p>
            </div>
          ))}
        </div>
      </Card>
      
      <Card title="نظرة عامة على تأثير الميزانية">
        <p className="text-sm text-slate-300">
          قرارات ميزانيتك حاسمة. نقص تمويل القطاعات الرئيسية مثل التعليم أو الرعاية الصحية يمكن أن يؤدي إلى مشاكل مجتمعية طويلة الأجل وتقليل الدعم الشعبي.
          وعلى العكس، يمكن أن يؤدي الإنفاق المفرط إلى إجهاد الخزينة. غالبًا ما يكون النهج المتوازن هو الأفضل.
          الخزينة الحالية: <span className={`font-semibold ${money >=0 ? 'text-green-400' : 'text-red-400'}`}>{formatMoney(money)}</span>.
        </p>
      </Card>
    </div>
  );
};

export default BudgetTab;
