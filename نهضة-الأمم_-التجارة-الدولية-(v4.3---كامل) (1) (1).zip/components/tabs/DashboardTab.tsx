
import React from 'react';
import { CountryState, BudgetAllocation, Policy, Law, TradeResource, TRADE_RESOURCE_LABELS_AR } from '../../types';
import Card from '../common/Card';
import { FaMoneyBillWave, FaUsers, FaShieldAlt, FaBalanceScale, FaFlask, FaLandmark, FaIndustry, FaPercentage, FaBriefcase, FaUniversity, FaHeartbeat, FaRoad, FaLightbulb } from 'react-icons/fa';
import { TECH_POINTS_PER_LEVEL, MAX_TECH_LEVEL } from '../../constants';

interface DashboardTabProps {
  countryState: CountryState;
  budget: BudgetAllocation;
  taxRates: { incomeTax: number; corporateTax: number; vatTax: number };
  policies: Policy[];
  laws: Law[];
  techProgress: number;
}

const StatCard: React.FC<{ title: string; value: string | number; icon: React.ReactNode; colorClass?: string, subValue?: string }> = ({ title, value, icon, colorClass = "text-sky-400", subValue }) => (
  <Card className="flex-1 min-w-[200px]">
    <div className="flex items-center space-x-3 rtl:space-x-reverse">
      <div className={`p-3 bg-slate-800 rounded-full ${colorClass}`}>{icon}</div>
      <div>
        <h4 className="text-sm text-slate-400">{title}</h4>
        <p className={`text-2xl font-bold ${colorClass}`}>{value}</p>
        {subValue && <p className="text-xs text-slate-500">{subValue}</p>}
      </div>
    </div>
  </Card>
);

const DashboardTab: React.FC<DashboardTabProps> = ({ countryState, budget, taxRates, policies, laws, techProgress }) => {
  const activePolicies = policies.filter(p => p.isActive);
  const passedLaws = laws.filter(l => l.isPassed);
  
  const techLevelProgressPercent = countryState.techLevel >= MAX_TECH_LEVEL ? 100 : (countryState.techLevel === 0 ? 0 : Math.floor((techProgress / (TECH_POINTS_PER_LEVEL * countryState.techLevel)) * 100));
  const nextTechLevelDisplay = countryState.techLevel + 1 > MAX_TECH_LEVEL ? MAX_TECH_LEVEL : countryState.techLevel + 1;
  const techLevelDisplay = `${countryState.techLevel} (${techLevelProgressPercent}% إلى م ${nextTechLevelDisplay})`;
  
  const formatMoney = (amount: number) => {
    const absAmount = Math.abs(amount);
    const sign = amount < 0 ? "-" : "";
    if (absAmount >= 1000000000) return `${sign}${(absAmount / 1000000000).toFixed(2)} مليار`;
    if (absAmount >= 1000000) return `${sign}${(absAmount / 1000000).toFixed(2)} مليون`;
    if (absAmount >= 1000) return `${sign}${(absAmount / 1000).toFixed(2)} ألف`;
    return `${sign}${absAmount.toFixed(0)}`;
  };

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-semibold text-sky-400">لوحة التحكم الوطنية - العام {countryState.year}</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        <StatCard title="الخزينة" value={`${formatMoney(countryState.money)}`} icon={<FaMoneyBillWave size={24} />} colorClass={countryState.money >= 0 ? "text-green-400" : "text-red-400"} subValue={`الدين: ${formatMoney(countryState.debt)}`} />
        <StatCard title="الولاء الشعبي" value={`${countryState.popularLoyalty.toFixed(1)}%`} icon={<FaUsers size={24} />} colorClass={countryState.popularLoyalty < 40 ? "text-red-400" : (countryState.popularLoyalty > 70 ? "text-green-400" : "text-amber-400")} />
        <StatCard title="الولاء العسكري" value={`${countryState.militaryLoyalty.toFixed(1)}%`} icon={<FaShieldAlt size={24} />} colorClass={countryState.militaryLoyalty < 40 ? "text-red-400" : (countryState.militaryLoyalty > 70 ? "text-green-400" : "text-amber-400")} />
        <StatCard title="الاستقرار السياسي" value={`${countryState.politicalStability.toFixed(1)}%`} icon={<FaBalanceScale size={24} />} colorClass={countryState.politicalStability < 40 ? "text-red-400" : (countryState.politicalStability > 70 ? "text-green-400" : "text-amber-400")} />
        <StatCard title="مستوى التكنولوجيا" value={techLevelDisplay} icon={<FaFlask size={24} />} />
        <StatCard title="رأس المال السياسي" value={countryState.politicalCapital} icon={<FaLandmark size={24} />} />
        <StatCard title="الناتج المحلي الإجمالي" value={`${formatMoney(countryState.gdp)}`} icon={<FaIndustry size={24} />} />
        <StatCard title="التضخم" value={`${countryState.inflation.toFixed(1)}%`} icon={<FaPercentage size={24} />} colorClass={countryState.inflation > 5 ? "text-red-400" : "text-green-400"} />
        <StatCard title="البطالة" value={`${countryState.unemployment.toFixed(1)}%`} icon={<FaBriefcase size={24} />} colorClass={countryState.unemployment > 8 ? "text-red-400" : "text-green-400"}/>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card title="تخصيص الميزانية">
          <ul className="space-y-1 text-sm">
            <li className="flex justify-between"><span><FaUniversity className="inline ml-2 rtl:mr-0 rtl:ml-2 text-sky-400"/>التعليم:</span> <span>{budget.education}%</span></li>
            <li className="flex justify-between"><span><FaHeartbeat className="inline ml-2 rtl:mr-0 rtl:ml-2 text-red-400"/>الصحة:</span> <span>{budget.health}%</span></li>
            <li className="flex justify-between"><span><FaShieldAlt className="inline ml-2 rtl:mr-0 rtl:ml-2 text-amber-400"/>الدفاع:</span> <span>{budget.defense}%</span></li>
            <li className="flex justify-between"><span><FaRoad className="inline ml-2 rtl:mr-0 rtl:ml-2 text-slate-400"/>البنية التحتية:</span> <span>{budget.infrastructure}%</span></li>
            <li className="flex justify-between"><span><FaLightbulb className="inline ml-2 rtl:mr-0 rtl:ml-2 text-yellow-400"/>البحث العلمي:</span> <span>{budget.research}%</span></li>
            <li className="flex justify-between"><span><FaUsers className="inline ml-2 rtl:mr-0 rtl:ml-2 text-green-400"/>الرعاية الاجتماعية:</span> <span>{budget.socialWelfare}%</span></li>
          </ul>
        </Card>

        <Card title="معدلات الضرائب">
          <ul className="space-y-1 text-sm">
            <li className="flex justify-between"><span>ضريبة الدخل:</span> <span>{taxRates.incomeTax}%</span></li>
            <li className="flex justify-between"><span>ضريبة الشركات:</span> <span>{taxRates.corporateTax}%</span></li>
            <li className="flex justify-between"><span>ضريبة القيمة المضافة:</span> <span>{taxRates.vatTax}%</span></li>
          </ul>
        </Card>

        <Card title="الموارد الوطنية">
          <ul className="space-y-1 text-sm">
            {Object.entries(countryState.nationalResources).map(([resource, amount]) => (
              <li key={resource} className="flex justify-between"><span>{TRADE_RESOURCE_LABELS_AR[resource as TradeResource]}:</span> <span>{amount.toLocaleString()} وحدة</span></li>
            ))}
          </ul>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card title="السياسات النشطة">
          {activePolicies.length > 0 ? (
            <ul className="space-y-1 text-sm list-disc list-inside pr-5 rtl:pl-5 rtl:pr-0">
              {activePolicies.map(p => <li key={p.id}>{p.nameAr}</li>)}
            </ul>
          ) : <p className="text-sm text-slate-400">لا توجد سياسات نشطة حاليًا.</p>}
        </Card>

        <Card title="القوانين المعتمدة">
          {passedLaws.length > 0 ? (
            <ul className="space-y-1 text-sm list-disc list-inside pr-5 rtl:pl-5 rtl:pr-0">
              {passedLaws.map(l => <li key={l.id}>{l.nameAr}</li>)}
            </ul>
          ) : <p className="text-sm text-slate-400">لم يتم تمرير أي قوانين خاصة بعد.</p>}
        </Card>
      </div>
    </div>
  );
};

export default DashboardTab;
