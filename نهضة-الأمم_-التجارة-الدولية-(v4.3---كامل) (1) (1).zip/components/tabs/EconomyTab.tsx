
import React from 'react';
import { CountryState } from '../../types';
import Card from '../common/Card';
import { FaPercentage, FaIndustry, FaBriefcase, FaMoneyBillWave } from 'react-icons/fa';
import { INITIAL_COUNTRY_STATE } from '../../constants';

interface EconomyTabProps {
  countryState: CountryState;
  taxRates: { incomeTax: number; corporateTax: number; vatTax: number };
  setTaxRates: React.Dispatch<React.SetStateAction<{ incomeTax: number; corporateTax: number; vatTax: number }>>;
}

const formatMoney = (amount: number) => {
    const absAmount = Math.abs(amount);
    const sign = amount < 0 ? "-" : "";
    if (absAmount >= 1000000000) return `${sign}${(absAmount / 1000000000).toFixed(2)} مليار`;
    if (absAmount >= 1000000) return `${sign}${(absAmount / 1000000).toFixed(2)} مليون`;
    if (absAmount >= 1000) return `${sign}${(absAmount / 1000).toFixed(2)} ألف`;
    return `${sign}${absAmount.toFixed(0)}`;
};


const EconomyTab: React.FC<EconomyTabProps> = ({ countryState, taxRates, setTaxRates }) => {
  const handleTaxChange = (taxType: keyof typeof taxRates, value: string) => {
    const numValue = parseInt(value, 10);
    if (!isNaN(numValue) && numValue >= 0 && numValue <= 100) {
      setTaxRates(prev => ({ ...prev, [taxType]: numValue }));
    }
  };

  const taxLabelsAr = {
    incomeTax: "ضريبة الدخل",
    corporateTax: "ضريبة الشركات",
    vatTax: "ضريبة القيمة المضافة"
  };

  const taxDescriptionsAr = {
    incomeTax: "تؤثر على الولاء الشعبي وإيرادات الحكومة.",
    corporateTax: "تؤثر على استثمار الشركات وإيرادات الحكومة.",
    vatTax: "تؤثر على إنفاق المستهلكين، الولاء الشعبي، والإيرادات."
  };


  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-semibold text-sky-400">إدارة الاقتصاد</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
                <FaIndustry className="text-2xl text-sky-400" />
                <div>
                    <h4 className="text-sm text-slate-400">الناتج المحلي الإجمالي</h4>
                    <p className="text-xl font-bold">{formatMoney(countryState.gdp)}</p>
                </div>
            </div>
        </Card>
        <Card>
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
                <FaPercentage className="text-2xl text-red-400" />
                <div>
                    <h4 className="text-sm text-slate-400">معدل التضخم</h4>
                    <p className="text-xl font-bold">{countryState.inflation.toFixed(1)}%</p>
                </div>
            </div>
        </Card>
        <Card>
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
                <FaBriefcase className="text-2xl text-amber-400" />
                <div>
                    <h4 className="text-sm text-slate-400">معدل البطالة</h4>
                    <p className="text-xl font-bold">{countryState.unemployment.toFixed(1)}%</p>
                </div>
            </div>
        </Card>
         <Card>
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
                <FaMoneyBillWave className="text-2xl text-green-400" />
                <div>
                    <h4 className="text-sm text-slate-400">الدين القومي</h4>
                    <p className="text-xl font-bold">{formatMoney(countryState.debt)}</p>
                </div>
            </div>
        </Card>
      </div>

      <Card title="سياسة الضرائب">
        <div className="space-y-4">
          {(['incomeTax', 'corporateTax', 'vatTax'] as const).map(taxType => (
            <div key={taxType}>
              <label htmlFor={taxType} className="block text-sm font-medium text-slate-300 capitalize mb-1">
                {taxLabelsAr[taxType]}: <span className="text-sky-400 font-bold">{taxRates[taxType]}%</span>
              </label>
              <input
                type="range"
                id={taxType}
                min="0"
                max="70" 
                value={taxRates[taxType]}
                onChange={(e) => handleTaxChange(taxType, e.target.value)}
                className="w-full h-2 bg-slate-600 rounded-lg appearance-none cursor-pointer accent-sky-500"
              />
              <p className="text-xs text-slate-400 mt-1">
                {taxDescriptionsAr[taxType]}
              </p>
            </div>
          ))}
        </div>
        <p className="mt-4 text-xs text-slate-400">
          تعديل معدلات الضرائب يؤثر بشكل مباشر على إيرادات الحكومة، الرأي العام، والنشاط الاقتصادي. الضرائب المرتفعة تزيد الإيرادات ولكنها قد تخنق النمو وتغضب المواطنين.
        </p>
      </Card>
      
      <Card title="التوقعات الاقتصادية">
        <p className="text-sm text-slate-300">
          الاقتصاد الوطني حاليًا {countryState.gdp > INITIAL_COUNTRY_STATE.gdp * 1.05 ? 'يشهد نموًا' : (countryState.gdp < INITIAL_COUNTRY_STATE.gdp * 0.95 ? 'في حالة ركود' : 'مستقر')}.
          التضخم {countryState.inflation > 5 ? 'مرتفع' : (countryState.inflation < 1 ? 'منخفض جدًا' : 'معتدل')}، والبطالة {countryState.unemployment > 8 ? 'مرتفعة' : (countryState.unemployment < 3 ? 'منخفضة' : 'معتدلة')}.
          الاستثمار المستمر في البنية التحتية والتكنولوجيا، إلى جانب السياسات المالية المستقرة، سيكون مفتاح الازدهار على المدى الطويل.
        </p>
      </Card>
    </div>
  );
};

export default EconomyTab;
