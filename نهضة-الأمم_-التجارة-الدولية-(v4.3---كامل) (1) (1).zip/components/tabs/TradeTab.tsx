
import React, { useState } from 'react';
import { CountryState, Nation, TradeResource, TRADE_RESOURCE_LABELS_AR } from '../../types';
import Card from '../common/Card';
import Button from '../common/Button';

interface TradeTabProps {
  countryState: CountryState;
  tradePartners: Nation[];
  onTrade: (partnerId: string, resource: TradeResource, amount: number, action: 'buy' | 'sell') => void;
}

const TradeTab: React.FC<TradeTabProps> = ({ countryState, tradePartners, onTrade }) => {
  const [selectedPartnerId, setSelectedPartnerId] = useState<string | null>(tradePartners.length > 0 ? tradePartners[0].id : null);
  const [selectedResource, setSelectedResource] = useState<TradeResource | null>(null);
  const [tradeAmount, setTradeAmount] = useState<number>(10);
  const [tradeAction, setTradeAction] = useState<'buy' | 'sell'>('buy');

  const selectedPartner = tradePartners.find(p => p.id === selectedPartnerId);

  const handleTradeAction = () => {
    if (selectedPartnerId && selectedResource && tradeAmount > 0) {
      onTrade(selectedPartnerId, selectedResource, tradeAmount, tradeAction);
    }
  };

  const resourceIcons: Record<TradeResource, string> = {
    [TradeResource.Oil]: '🛢️',
    [TradeResource.Minerals]: '⛏️',
    [TradeResource.Food]: '🍎',
    [TradeResource.IndustrialGoods]: '🏭',
    [TradeResource.TechComponents]: '⚙️',
    [TradeResource.LuxuryGoods]: '💎',
  };

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-semibold text-sky-400">التجارة الدولية</h2>
      
      <Card title="مواردك الوطنية">
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {Object.entries(countryState.nationalResources).map(([resource, amount]) => (
            <div key={resource} className="p-3 bg-slate-600 rounded-md shadow">
              <span className="text-2xl">{resourceIcons[resource as TradeResource]}</span>
              <p className="font-semibold text-slate-200">{TRADE_RESOURCE_LABELS_AR[resource as TradeResource]}</p>
              <p className="text-lg text-sky-400">{amount.toLocaleString()}</p>
            </div>
          ))}
        </div>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card title="الشركاء التجاريون" className="md:col-span-1">
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {tradePartners.map(partner => (
              <button
                key={partner.id}
                onClick={() => { setSelectedPartnerId(partner.id); setSelectedResource(null); setTradeAmount(10); }}
                className={`w-full p-3 rounded-md text-right rtl:text-right transition-colors ${selectedPartnerId === partner.id ? 'bg-sky-600 text-white' : 'bg-slate-600 hover:bg-slate-500'}`}
              >
                <p className="font-semibold">{partner.nameAr}</p>
                <p className="text-xs">العلاقة: {partner.relation}/100 ({partner.ideologyAr || partner.ideology})</p>
              </button>
            ))}
          </div>
        </Card>

        {selectedPartner && (
          <Card title={`التجارة مع ${selectedPartner.nameAr}`} className="md:col-span-2">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">اختر المورد:</label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {Object.values(TradeResource).map(res => {
                    const canBuy = selectedPartner.sells[res];
                    const canSell = selectedPartner.buys[res];
                    const availableToBuy = canBuy ? canBuy.availability : 0;
                    const demandToSell = canSell ? canSell.demand : 0;

                    return (
                        <button
                        key={res}
                        onClick={() => {setSelectedResource(res); setTradeAmount(10);}}
                        disabled={tradeAction === 'buy' ? !canBuy || availableToBuy <=0 : !canSell || demandToSell <=0}
                        className={`p-3 rounded-md text-right rtl:text-right transition-colors text-sm
                                    ${selectedResource === res ? 'bg-sky-500 text-white ring-2 ring-sky-300' : 'bg-slate-600 hover:bg-slate-500 disabled:opacity-50 disabled:cursor-not-allowed'}`}
                        >
                        <span className="text-xl ml-2 rtl:mr-0 rtl:ml-2">{resourceIcons[res]}</span> {TRADE_RESOURCE_LABELS_AR[res]}
                        {tradeAction === 'buy' && canBuy && <span className="block text-xs">السعر: ${canBuy.price}, متاح: {availableToBuy}</span>}
                        {tradeAction === 'sell' && canSell && <span className="block text-xs">السعر: ${canSell.price}, الطلب: {demandToSell}</span>}
                        {(tradeAction === 'buy' && (!canBuy || availableToBuy <=0)) && <span className="block text-xs text-red-400">غير متوفر للبيع</span>}
                        {(tradeAction === 'sell' && (!canSell || demandToSell <=0)) && <span className="block text-xs text-red-400">لا يوجد طلب</span>}
                        </button>
                    );
                  })}
                </div>
              </div>

              {selectedResource && (
                <>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">الإجراء:</label>
                    <div className="flex space-x-2 rtl:space-x-reverse">
                      <Button variant={tradeAction === 'buy' ? 'primary' : 'secondary'} onClick={() => setTradeAction('buy')}>شراء</Button>
                      <Button variant={tradeAction === 'sell' ? 'primary' : 'secondary'} onClick={() => setTradeAction('sell')}>بيع</Button>
                    </div>
                  </div>
                  <div>
                    <label htmlFor="tradeAmount" className="block text-sm font-medium text-slate-300 mb-1">الكمية: {tradeAmount}</label>
                    <input
                      type="range"
                      id="tradeAmount"
                      min="1"
                      max={tradeAction === 'buy' 
                           ? (selectedPartner.sells[selectedResource]?.availability || 1) 
                           : (Math.min(countryState.nationalResources[selectedResource], selectedPartner.buys[selectedResource]?.demand || 0) || 1)}
                      value={tradeAmount}
                      onChange={(e) => setTradeAmount(Math.max(1, parseInt(e.target.value)))} // Ensure amount is at least 1
                      className="w-full h-2 bg-slate-500 rounded-lg appearance-none cursor-pointer accent-sky-500"
                    />
                     <input
                      type="number"
                      id="tradeAmountNum"
                      min="1"
                      max={tradeAction === 'buy' 
                           ? (selectedPartner.sells[selectedResource]?.availability || 1) 
                           : (Math.min(countryState.nationalResources[selectedResource], selectedPartner.buys[selectedResource]?.demand || 0) || 1)}
                      value={tradeAmount}
                      onChange={(e) => setTradeAmount(Math.max(1, parseInt(e.target.value)))} // Ensure amount is at least 1
                      className="w-full mt-2 p-2 bg-slate-700 border border-slate-600 rounded-md focus:ring-sky-500 focus:border-sky-500"
                    />
                  </div>
                  <Button 
                    onClick={handleTradeAction} 
                    variant="success" 
                    className="w-full"
                    disabled={tradeAmount <= 0 || (tradeAction === 'buy' && (!selectedPartner.sells[selectedResource] || selectedPartner.sells[selectedResource]!.availability < tradeAmount )) || (tradeAction === 'sell' && (!selectedPartner.buys[selectedResource] || countryState.nationalResources[selectedResource] < tradeAmount || selectedPartner.buys[selectedResource]!.demand < tradeAmount  ))}
                  >
                    تأكيد {tradeAction === 'buy' ? 'الشراء' : 'البيع'}
                  </Button>
                  { selectedResource && tradeAmount > 0 &&
                    <p className="text-sm text-center text-slate-400">
                        التكلفة/الإيراد الإجمالي: $
                        {tradeAction === 'buy' 
                            ? (tradeAmount * (selectedPartner.sells[selectedResource]?.price || 0)).toLocaleString()
                            : (tradeAmount * (selectedPartner.buys[selectedResource]?.price || 0)).toLocaleString()
                        }
                    </p>
                  }
                </>
              )}
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};

export default TradeTab;
