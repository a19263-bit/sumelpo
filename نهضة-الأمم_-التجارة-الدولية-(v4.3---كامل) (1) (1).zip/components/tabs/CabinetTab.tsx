import React from 'react';
import { Advisor, CountryState, BudgetAllocation, Policy, Law, PoliticalParty, TradeUnion } from '../../types';
import Card from '../common/Card';
import { FaUserTie, FaRegCommentDots, FaHeartbeat } from 'react-icons/fa';

interface CabinetTabProps {
  advisors: Advisor[];
  countryState: CountryState;
  budget: BudgetAllocation;
  policies: Policy[];
  laws: Law[];
  politicalParties: PoliticalParty[];
  tradeUnions: TradeUnion[];
}

const CabinetTab: React.FC<CabinetTabProps> = ({ advisors, countryState, budget, policies, laws, politicalParties, tradeUnions }) => {
  
  const getPriorityColor = (priority: 'high' | 'medium' | 'low'): string => {
    if (priority === 'high') return 'border-red-500';
    if (priority === 'medium') return 'border-amber-500';
    return 'border-sky-500';
  };

  const getPriorityTextAndColor = (priority: 'high' | 'medium' | 'low'): {text: string, color: string} => {
    if (priority === 'high') return {text: 'عالية الأهمية', color: 'text-red-400'};
    if (priority === 'medium') return {text: 'متوسطة الأهمية', color: 'text-amber-400'};
    return {text: 'منخفضة الأهمية', color: 'text-sky-400'};
  };


  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-semibold text-sky-400">الديوان الرئاسي ومجلس المستشارين</h2>
      <p className="text-sm text-slate-400">
        استمع إلى نصائح كبار مستشاريك. يقدمون رؤى حول الوضع الحالي للدولة بناءً على خبراتهم. تجاهل نصائحهم قد يكون له عواقب.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {advisors.map(advisor => {
          const advice = advisor.getAdvice(countryState, budget, policies, laws, politicalParties, tradeUnions);
          const priorityStyle = getPriorityTextAndColor(advice.priority);
          return (
            <Card 
              key={advisor.id} 
              title='' 
              className={`border-t-4 ${getPriorityColor(advice.priority)} flex flex-col`}
            >
              <div className="flex items-center mb-3">
                {advisor.imageUrl ? (
                    <img src={advisor.imageUrl} alt={advisor.name} className="w-16 h-16 rounded-full mr-4 rtl:ml-4 border-2 border-slate-600"/>
                ) : (
                    <div className="w-16 h-16 rounded-full mr-4 rtl:ml-4 bg-slate-600 flex items-center justify-center text-slate-400">
                        <FaUserTie size={30} />
                    </div>
                )}
                <div>
                  <h3 className="text-lg font-semibold text-sky-300">{advisor.name}</h3>
                  <p className="text-sm text-slate-400">{advisor.roleAr} (<span className="text-xs text-slate-500">{advisor.nameAr}</span>)</p>
                </div>
              </div>
              
              <div className="mb-3 flex items-center">
                 <FaHeartbeat className={`mr-2 rtl:ml-2 ${advisor.loyalty > 60 ? 'text-green-400' : advisor.loyalty > 30 ? 'text-amber-400' : 'text-red-400'}`} />
                 <span className="text-xs text-slate-400">الولاء: </span>
                 <span className={`text-sm font-semibold ml-1 rtl:mr-1 ${advisor.loyalty > 60 ? 'text-green-300' : advisor.loyalty > 30 ? 'text-amber-300' : 'text-red-300'}`}>
                    {advisor.loyalty}%
                 </span>
              </div>

              <div className="bg-slate-800 p-3 rounded-md flex-grow">
                <div className="flex items-center mb-2">
                    <FaRegCommentDots className={`mr-2 rtl:ml-2 ${priorityStyle.color}`} />
                    <h4 className={`text-sm font-semibold ${priorityStyle.color}`}>نصيحة ({priorityStyle.text}):</h4>
                </div>
                <p className="text-sm text-slate-300 whitespace-pre-line">{advice.messageAr}</p>
              </div>
            </Card>
          );
        })}
      </div>
      {advisors.length === 0 && <p className="text-slate-400">لا يوجد مستشارون معينون حاليًا.</p>}
    </div>
  );
};

export default CabinetTab;