import React from 'react';
import { PoliticalParty, CountryState, POLITICAL_PARTY_IDEOLOGY_LABELS_AR, TradeUnion, TRADE_UNION_INDUSTRY_LABELS_AR } from '../../types';
import Card from '../common/Card';
import { INITIAL_YEAR, INITIAL_COUNTRY_STATE } from '../../constants';
import { FaExclamationTriangle, FaUsersSlash, FaBalanceScale, FaIndustry, FaUsers, FaFistRaised, FaSmile, FaRegThumbsUp, FaRegThumbsDown } from 'react-icons/fa';


interface InternalAffairsTabProps {
  politicalParties: PoliticalParty[];
  countryState: CountryState;
  tradeUnions: TradeUnion[];
}

const InternalAffairsTab: React.FC<InternalAffairsTabProps> = ({ politicalParties, countryState, tradeUnions }) => {
  const nextElectionYear = INITIAL_YEAR + (Math.floor((countryState.year - INITIAL_YEAR) / 4) + 1) * 4;
  const yearsToElection = nextElectionYear - countryState.year;

  const totalSupport = politicalParties.reduce((sum, party) => sum + party.support, 0);

  const getYearsRemainingText = (years: number): string => {
    if (years <= 0) return 'هذا العام';
    if (years === 1) return 'سنة واحدة';
    if (years === 2) return 'سنتان';
    if (years >= 3 && years <= 10) return `${years} سنوات`;
    return `${years} سنة`;
  };
  
  const electionMessageYearsPart = (years: number): string => {
    if (years <= 0) return getYearsRemainingText(years);
    if (years === 1) return 'سنة واحدة';
    if (years === 2) return 'سنتان';
    if (years >= 3 && years <= 10) return 'سنوات';
    return 'سنة';
  }

  const getOppositionStanceDescription = (): string => {
    if (countryState.oppositionDiscontent > 75) return "المعارضة غاضبة بشدة وقد تلجأ إلى إجراءات تصعيدية.";
    if (countryState.oppositionDiscontent > 50) return "المعارضة غير راضية وتنتقد الحكومة علانية وباستمرار.";
    if (countryState.oppositionDiscontent > 25) return "هناك بعض الاستياء بين صفوف المعارضة بشأن سياسات معينة.";
    return "المعارضة هادئة نسبيًا في الوقت الحالي.";
  };
  
  const getOppositionStrengthDescription = (): string => {
    if (countryState.oppositionStrength > 70) return "قوية جداً ومؤثرة.";
    if (countryState.oppositionStrength > 45) return "معتدلة القوة ولها حضور ملحوظ.";
    if (countryState.oppositionStrength > 20) return "محدودة القوة وتأثيرها ضئيل.";
    return "ضعيفة وغير مؤثرة بشكل كبير.";
  };

  const getConfidenceDescription = (confidence: number): string => {
    if (confidence > 75) return "ثقة عالية جداً، تتمتع الحكومة بدعم قوي.";
    if (confidence > 50) return "ثقة معتدلة، الأداء جيد بشكل عام.";
    if (confidence > 30) return "ثقة منخفضة، هناك شكوك حول قدرة الحكومة.";
    return "ثقة منهارة، الحكومة على وشك السقوط.";
  };


  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-semibold text-sky-400">الشؤون الداخلية</h2>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card title="وضع المعارضة">
            <div className="p-2 bg-slate-700 rounded-lg shadow mb-2">
                <div className="flex items-center mb-1">
                    <FaUsersSlash className={`mr-2 rtl:ml-2 text-xl ${countryState.oppositionStrength > 50 ? 'text-red-400' : 'text-amber-400'}`} />
                    <h4 className="text-md font-semibold text-slate-200">قوة المعارضة</h4>
                </div>
                <p className={`text-2xl font-bold ${countryState.oppositionStrength > 50 ? 'text-red-300' : 'text-amber-300'}`}>{countryState.oppositionStrength.toFixed(0)}%</p>
                <p className="text-xs text-slate-400">{getOppositionStrengthDescription()}</p>
            </div>
            <div className="p-2 bg-slate-700 rounded-lg shadow">
                 <div className="flex items-center mb-1">
                    <FaExclamationTriangle className={`mr-2 rtl:ml-2 text-xl ${countryState.oppositionDiscontent > 50 ? 'text-red-500' : 'text-yellow-500'}`} />
                    <h4 className="text-md font-semibold text-slate-200">سخط المعارضة</h4>
                </div>
                <p className={`text-2xl font-bold ${countryState.oppositionDiscontent > 50 ? 'text-red-400' : 'text-yellow-400'}`}>{countryState.oppositionDiscontent.toFixed(0)}%</p>
                <p className="text-xs text-slate-400">{getOppositionStanceDescription()}</p>
            </div>
        </Card>
        <Card title="الثقة الحكومية">
            <div className="p-2 bg-slate-700 rounded-lg shadow">
                <div className="flex items-center mb-1">
                    <FaBalanceScale className={`mr-2 rtl:ml-2 text-xl ${countryState.governmentConfidence > 50 ? 'text-green-400' : 'text-red-400'}`} />
                    <h4 className="text-md font-semibold text-slate-200">مستوى الثقة</h4>
                </div>
                <p className={`text-2xl font-bold ${countryState.governmentConfidence > 50 ? 'text-green-300' : 'text-red-300'}`}>{countryState.governmentConfidence.toFixed(0)}%</p>
                <p className="text-xs text-slate-400">{getConfidenceDescription(countryState.governmentConfidence)}</p>
            </div>
             <p className="text-xs text-slate-500 mt-2">
                يمثل مدى ثقة المؤسسات التشريعية والشعبية في قدرة الحكومة على الإدارة الفعالة. يؤثر على تمرير القوانين والاستقرار العام.
            </p>
        </Card>
         <Card title="الانتخابات القادمة">
            <p className="text-lg text-slate-300 text-center">
              عام <span className="font-bold text-amber-400">{nextElectionYear}</span> 
            </p>
            <p className="text-md text-slate-400 mt-1 text-center">
                {yearsToElection > 0 ? `(${yearsToElection} ${electionMessageYearsPart(yearsToElection)} متبقية)` : `(${electionMessageYearsPart(yearsToElection)})`}
            </p>
            <p className="text-xs text-slate-500 mt-2">
              أداؤك سيحدد فرص إعادة انتخابك.
            </p>
        </Card>
      </div>
      
      <Card title="النقابات العمالية">
        <p className="text-sm text-slate-300 mb-4">
          تمثل النقابات مصالح العمال في مختلف القطاعات. رضاهم وقوتهم يؤثران على الاستقرار الاقتصادي والاجتماعي.
        </p>
        {tradeUnions.length === 0 && <p className="text-slate-400">لا توجد نقابات عمالية نشطة حاليًا.</p>}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {tradeUnions.map(union => (
            <div key={union.id} className="p-3 bg-slate-700 rounded-md shadow">
              <h4 className="text-md font-semibold text-sky-300 mb-1">{union.nameAr}</h4>
              <p className="text-xs text-slate-400 mb-2">القطاع: {TRADE_UNION_INDUSTRY_LABELS_AR[union.industryFocus]}</p>
              
              <div className="flex items-center mb-1" title="قوة العضوية / النفوذ">
                <FaUsers className="mr-2 rtl:ml-2 text-slate-400" />
                <span className="text-xs text-slate-300">القوة:</span>
                <div className="w-full bg-slate-600 rounded-full h-1.5 mx-2">
                    <div className="bg-sky-500 h-1.5 rounded-full" style={{ width: `${union.membershipStrength}%`}}></div>
                </div>
                <span className="text-xs text-sky-400">{union.membershipStrength}%</span>
              </div>

              <div className="flex items-center mb-1" title="مستوى النضالية / الاستعداد للاحتجاج">
                 <FaFistRaised className={`mr-2 rtl:ml-2 ${union.militancy > 60 ? 'text-red-400' : union.militancy > 30 ? 'text-amber-400' : 'text-slate-400'}`} />
                 <span className="text-xs text-slate-300">النضالية:</span>
                 <div className="w-full bg-slate-600 rounded-full h-1.5 mx-2">
                    <div className={`${union.militancy > 60 ? 'bg-red-500' : union.militancy > 30 ? 'bg-amber-500' : 'bg-slate-500'} h-1.5 rounded-full`} style={{ width: `${union.militancy}%`}}></div>
                </div>
                 <span className={`text-xs ${union.militancy > 60 ? 'text-red-400' : union.militancy > 30 ? 'text-amber-400' : 'text-slate-400'}`}>{union.militancy}%</span>
              </div>

              <div className="flex items-center" title="مستوى الرضا عن الأوضاع الحالية">
                 {union.satisfaction > 60 ? <FaRegThumbsUp className="mr-2 rtl:ml-2 text-green-400" /> : <FaRegThumbsDown className="mr-2 rtl:ml-2 text-red-400" /> }
                 <span className="text-xs text-slate-300">الرضا:</span>
                 <div className="w-full bg-slate-600 rounded-full h-1.5 mx-2">
                    <div className={`${union.satisfaction > 60 ? 'bg-green-500' : union.satisfaction > 30 ? 'bg-yellow-500' : 'bg-red-500'} h-1.5 rounded-full`} style={{ width: `${union.satisfaction}%`}}></div>
                </div>
                 <span className={`text-xs ${union.satisfaction > 60 ? 'text-green-400' : union.satisfaction > 30 ? 'text-yellow-400' : 'text-red-400'}`}>{union.satisfaction}%</span>
              </div>
            </div>
          ))}
        </div>
      </Card>


      <Card title="المشهد السياسي الحزبي">
        <p className="text-sm text-slate-300 mb-4">
          الأحزاب السياسية تشكل البرلمان وتؤثر على تمرير القوانين. الأحزاب المعارضة لسياساتك قد تزيد من سخط المعارضة.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {politicalParties.map(party => (
            <div key={party.id} className="p-4 bg-slate-700 rounded-md shadow">
              <h4 className="text-lg font-semibold text-sky-300">{party.nameAr}</h4>
              <p className="text-sm text-slate-400">الأيديولوجيا: {POLITICAL_PARTY_IDEOLOGY_LABELS_AR[party.ideology]}</p>
              <p className="text-sm text-slate-400">الدعم البرلماني: {totalSupport > 0 ? ((party.support / totalSupport) * 100).toFixed(1) : 0}%</p>
               <div className="w-full bg-slate-600 rounded-full h-2.5 mt-2">
                <div className="bg-sky-500 h-2.5 rounded-full" style={{ width: `${totalSupport > 0 ? (party.support / totalSupport) * 100 : 0}%` }}></div>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};

export default InternalAffairsTab;