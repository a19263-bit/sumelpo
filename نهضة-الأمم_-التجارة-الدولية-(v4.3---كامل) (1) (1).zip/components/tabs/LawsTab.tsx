import React from 'react';
import { Law, CountryState, PoliticalParty } from '../../types';
import Card from '../common/Card';
import Button from '../common/Button';

interface LawsTabProps {
  laws: Law[];
  onPassLaw: (lawId: string) => void;
  countryState: CountryState;
  politicalParties: PoliticalParty[];
}

const LawsTab: React.FC<LawsTabProps> = ({ laws, onPassLaw, countryState, politicalParties }) => {
  
  const calculateParliamentarySupport = (law: Law): number => {
    let totalWeightedSupport = 0;

    politicalParties.forEach(party => {
      let partySupportFactor = 0.4; // Base willingness to support any law

      // Ideological alignment with the law type increases support
      if ((law.id.includes("health") || law.id.includes("education") || law.id.includes("welfare")) && (party.ideology === "Liberal" || party.ideology === "Socialist" || party.ideology === "Green")) partySupportFactor = 0.8;
      else if (law.id.includes("research") && (party.ideology === "Liberal" || party.ideology === "Green")) partySupportFactor = 0.7;
      else if ((law.id.includes("defense") || law.id.includes("security")) && (party.ideology === "Conservative" || party.ideology === "Nationalist")) partySupportFactor = 0.8;
      else if (law.id.includes("economic") && (party.ideology === "Conservative" || party.ideology === "Liberal")) partySupportFactor = 0.6;
      else if (law.id.includes("corruption") && (party.ideology === "Liberal" || party.ideology === "Populist")) partySupportFactor = 0.75;


      // If the party's ideology is listed as opposing this law, and opposition is discontent, reduce their support
      if (law.opposingIdeologies?.includes(party.ideology)) {
        // Reduce support more if overall opposition discontent is high
        partySupportFactor *= (1 - (countryState.oppositionDiscontent / 120)); // Max reduction factor, e.g. 1 - 100/120 = 0.16 multiplier
        partySupportFactor = Math.max(0, partySupportFactor); // Ensure not negative
      }
      
      totalWeightedSupport += (party.support * partySupportFactor);
    });
    
    // Total weighted support is effectively the percentage of parliament inclined to support.
    // Now add general factors like political stability and capital.
    // Reduce impact if opposition strength is high.
    const effectiveSupport = Math.min(100, 
        (totalWeightedSupport * 0.6) + // Base parliamentary inclination
        (countryState.politicalStability / 4) + 
        (countryState.politicalCapital / 12) -
        (countryState.oppositionStrength / 15) // Strong opposition makes it harder to pass laws
    );
    return parseFloat(Math.max(0, effectiveSupport).toFixed(1)); // Ensure it's not negative
  };

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-semibold text-sky-400">التشريعات</h2>
      <p className="text-sm text-slate-400">اقترح ومرر القوانين التي لها آثار كبيرة ودائمة على أمتك. يتطلب تمرير القوانين موارد وتقدمًا تكنولوجيًا ودعمًا برلمانيًا. قوة المعارضة وسخطها قد تجعل تمرير القوانين أكثر صعوبة.</p>
      <p className="text-md text-amber-400">رأس المال السياسي المتاح: {countryState.politicalCapital}</p>
      <p className="text-md text-sky-400">مستوى التكنولوجيا الحالي: {countryState.techLevel}</p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {laws.map(law => (
          <Card key={law.id} title={law.nameAr} className="flex flex-col justify-between">
            <div>
              <p className="text-sm text-slate-300 mb-3">{law.descriptionAr}</p>
              <div className="text-xs text-slate-400 space-y-1 mb-3">
                <p>التكلفة: {law.costMoney.toLocaleString()} $ و {law.costPoliticalCapital} رأس مال سياسي</p>
                <p>متطلب التكنولوجيا: المستوى {law.techRequirement}</p>
                <p>الدعم المطلوب: {law.parliamentarySupportThreshold}% (التقدير الحالي: <span className={calculateParliamentarySupport(law) >= law.parliamentarySupportThreshold ? 'text-green-400' : 'text-red-400'}>{calculateParliamentarySupport(law)}%</span>)</p>
              </div>
              {law.isPassed ? (
                <p className="text-lg font-semibold text-green-400">تم التمرير</p>
              ) : (
                 <p className="text-sm font-semibold text-amber-400">لم يتم التمرير</p>
              )}
            </div>
            {!law.isPassed && (
              <Button
                onClick={() => onPassLaw(law.id)}
                disabled={
                  countryState.money < law.costMoney ||
                  countryState.politicalCapital < law.costPoliticalCapital ||
                  countryState.techLevel < law.techRequirement ||
                  calculateParliamentarySupport(law) < law.parliamentarySupportThreshold
                }
                variant="primary"
                className="w-full mt-2"
              >
                محاولة تمرير القانون
              </Button>
            )}
             {countryState.money < law.costMoney && !law.isPassed && <p className="text-xs text-red-500 mt-1">أموال غير كافية.</p>}
             {countryState.politicalCapital < law.costPoliticalCapital && !law.isPassed && <p className="text-xs text-red-500 mt-1">رأس مال سياسي غير كافٍ.</p>}
             {countryState.techLevel < law.techRequirement && !law.isPassed && <p className="text-xs text-red-500 mt-1">مستوى التكنولوجيا منخفض جدًا.</p>}
             {calculateParliamentarySupport(law) < law.parliamentarySupportThreshold && !law.isPassed && <p className="text-xs text-red-500 mt-1">الدعم البرلماني المتوقع غير كافٍ.</p>}
          </Card>
        ))}
      </div>
    </div>
  );
};

export default LawsTab;