
import React from 'react';
import { Nation } from '../../types';
import Card from '../common/Card';
import Button from '../common/Button';

interface ExternalAffairsTabProps {
  tradePartners: Nation[];
  onDiplomacy: (partnerId: string, actionType: 'improve_relations' | 'decrease_relations') => void;
  politicalCapital: number;
}

const ExternalAffairsTab: React.FC<ExternalAffairsTabProps> = ({ tradePartners, onDiplomacy, politicalCapital }) => {
  const getRelationColor = (relation: number): string => {
    if (relation > 70) return 'text-green-400';
    if (relation > 40) return 'text-sky-400';
    if (relation > 20) return 'text-amber-400';
    return 'text-red-400';
  };
  
  const getRelationDescriptionAr = (relation: number): string => {
    if (relation > 85) return 'حليف قوي';
    if (relation > 65) return 'صديقة';
    if (relation > 40) return 'محايدة';
    if (relation > 20) return 'متوترة';
    if (relation > 0) return 'عدائية';
    return 'شديدة العداء';
  };

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-semibold text-sky-400">الشؤون الخارجية والدبلوماسية</h2>
      <p className="text-sm text-slate-400">قم بإدارة علاقات أمتك مع الدول الأخرى. العلاقات الجيدة يمكن أن تؤدي إلى صفقات تجارية مفيدة ودعم دولي، بينما العلاقات السيئة يمكن أن تؤدي إلى صراع أو عزلة.</p>
      <p className="text-md text-amber-400">رأس المال السياسي المتاح للدبلوماسية: {politicalCapital}</p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {tradePartners.map(partner => (
          <Card key={partner.id} title={partner.nameAr} className="flex flex-col justify-between">
            <div>
              <p className={`text-lg font-semibold ${getRelationColor(partner.relation)}`}>
                العلاقة: {partner.relation}/100 ({getRelationDescriptionAr(partner.relation)})
              </p>
              <p className="text-sm text-slate-400 mb-1">الأيديولوجيا: {partner.ideologyAr || partner.ideology || 'غير معروف'}</p>
              <div className="w-full bg-slate-600 rounded-full h-2.5 my-2">
                <div className={`${getRelationColor(partner.relation).replace('text-','bg-')} h-2.5 rounded-full`} style={{ width: `${partner.relation}%` }}></div>
              </div>
              <p className="text-xs text-slate-400 mt-1">تكلفة الإجراءات الدبلوماسية 10 رأس مال سياسي.</p>
            </div>
            <div className="mt-4 flex space-x-2 rtl:space-x-reverse">
              <Button 
                onClick={() => onDiplomacy(partner.id, 'improve_relations')}
                variant="success" 
                size="sm"
                disabled={politicalCapital < 10 || partner.relation >=100}
                className="flex-1"
                >
                تحسين العلاقات
              </Button>
              <Button 
                onClick={() => onDiplomacy(partner.id, 'decrease_relations')}
                variant="danger" 
                size="sm"
                disabled={politicalCapital < 10 || partner.relation <=0}
                className="flex-1"
                >
                تدهور العلاقات
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default ExternalAffairsTab;
