
import React from 'react';
import { Policy } from '../../types';
import Card from '../common/Card';
import Button from '../common/Button';

interface PoliciesTabProps {
  policies: Policy[];
  onTogglePolicy: (policyId: string) => void;
  politicalCapital: number;
}

const PoliciesTab: React.FC<PoliciesTabProps> = ({ policies, onTogglePolicy, politicalCapital }) => {
  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-semibold text-sky-400">السياسات الوطنية</h2>
      <p className="text-sm text-slate-400">قم بتفعيل أو إلغاء تفعيل السياسات التي تشكل أمتك. كل تغيير يكلف رأس مال سياسي.</p>
      <p className="text-md text-amber-400">رأس المال السياسي المتاح: {politicalCapital}</p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {policies.map(policy => (
          <Card key={policy.id} title={policy.nameAr} className="flex flex-col justify-between">
            <div>
              <p className="text-sm text-slate-300 mb-3">{policy.descriptionAr}</p>
              <p className="text-xs text-slate-400 mb-1">تكلفة التغيير: {policy.costPoliticalCapitalToggle} رأس مال سياسي</p>
              <p className={`text-sm font-semibold mb-3 ${policy.isActive ? 'text-green-400' : 'text-red-400'}`}>
                الحالة: {policy.isActive ? 'نشطة' : 'غير نشطة'}
              </p>
            </div>
            <Button
              onClick={() => onTogglePolicy(policy.id)}
              disabled={politicalCapital < policy.costPoliticalCapitalToggle}
              variant={policy.isActive ? 'warning' : 'success'}
              className="w-full mt-2"
            >
              {policy.isActive ? 'إلغاء التفعيل' : 'تفعيل السياسة'}
            </Button>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default PoliciesTab;
